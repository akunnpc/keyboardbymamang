package com.example.data.theme

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "keyboard_themes")
data class KeyboardTheme(
    @PrimaryKey val id: String,
    val name: String,
    val backgroundColor: String,
    val keyBackgroundColor: String,
    val keyTextColor: String,
    val accentColor: String,
    val isCustom: Boolean = false,
    val backgroundImagePath: String? = null,
    val keyBordersEnabled: Boolean = true
) {
    companion object {
        val DARK_MINIMAL = KeyboardTheme(
            id = "dark_minimal",
            name = "Dark Minimal",
            backgroundColor = "#1A1A1A",
            keyBackgroundColor = "#2D2D2D",
            keyTextColor = "#FFFFFF",
            accentColor = "#4FC3F7",
            isCustom = false
        )

        val LIGHT_CLEAN = KeyboardTheme(
            id = "light_clean",
            name = "Light Clean",
            backgroundColor = "#F5F5F5",
            keyBackgroundColor = "#E0E0E0",
            keyTextColor = "#000000",
            accentColor = "#4CAF50",
            isCustom = false
        )

        val NEON_CYBERPUNK = KeyboardTheme(
            id = "neon_cyberpunk",
            name = "Neon Cyberpunk",
            backgroundColor = "#0D0114",
            keyBackgroundColor = "#1B022B",
            keyTextColor = "#FF2E9A",
            accentColor = "#00FFF0",
            isCustom = false
        )

        val SOLARIZED = KeyboardTheme(
            id = "solarized",
            name = "Solarized Sepia",
            backgroundColor = "#FDF6E3",
            keyBackgroundColor = "#EEE8D5",
            keyTextColor = "#586E75",
            accentColor = "#B58900",
            isCustom = false
        )

        val PRESETS = listOf(DARK_MINIMAL, LIGHT_CLEAN, NEON_CYBERPUNK, SOLARIZED)
    }
}

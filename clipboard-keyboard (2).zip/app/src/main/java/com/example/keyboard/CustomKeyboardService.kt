package com.example.keyboard

import android.content.ClipboardManager
import android.content.Context
import android.inputmethodservice.InputMethodService
import android.view.View
import android.view.inputmethod.EditorInfo
import com.example.data.AppDatabase
import com.example.data.clipboard.ClipboardRepository
import com.example.data.theme.KeyboardTheme
import com.example.data.theme.ThemeRepository
import com.example.util.SettingsManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class CustomKeyboardService : InputMethodService(), KeyboardView.KeyboardActionListener {

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private lateinit var settingsManager: SettingsManager
    private lateinit var clipboardRepo: ClipboardRepository
    private lateinit var themeRepo: ThemeRepository
    private var clipboardListener: ClipboardManager.OnPrimaryClipChangedListener? = null

    private var activeTheme: KeyboardTheme = KeyboardTheme.DARK_MINIMAL

    override fun onCreate() {
        super.onCreate()
        settingsManager = SettingsManager(this)
        
        val db = AppDatabase.getInstance(this)
        clipboardRepo = ClipboardRepository(db.clipboardDao())
        themeRepo = ThemeRepository(db.themeDao())

        // Monitor clipboard copy events when the keyboard is active/open
        setupClipboardListener()

        // Handle auto-delete
        runAutoDeleteTask()
    }

    private fun setupClipboardListener() {
        val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as? ClipboardManager
        if (clipboard != null) {
            clipboardListener = ClipboardManager.OnPrimaryClipChangedListener {
                if (settingsManager.isClipboardEnabled) {
                    val clip = clipboard.primaryClip
                    if (clip != null && clip.itemCount > 0) {
                        val text = clip.getItemAt(0).text?.toString()
                        if (!text.isNullOrEmpty()) {
                            serviceScope.launch(Dispatchers.IO) {
                                clipboardRepo.insertText(text)
                            }
                        }
                    }
                }
            }
            clipboard.addPrimaryClipChangedListener(clipboardListener)
        }
    }

    private fun runAutoDeleteTask() {
        val days = settingsManager.autoDeleteDays
        if (days > 0) {
            serviceScope.launch(Dispatchers.IO) {
                clipboardRepo.deleteOlderThanDays(days)
            }
        }
    }

    override fun onCreateInputView(): View {
        // Load settings-configured theme
        val themeId = settingsManager.selectedThemeId
        val preset = KeyboardTheme.PRESETS.firstOrNull { it.id == themeId }
        
        if (preset != null) {
            activeTheme = preset
        } else {
            // Load custom theme from DB asynchronously, fall back to default initially
            activeTheme = KeyboardTheme.DARK_MINIMAL
            serviceScope.launch {
                try {
                    val dbTheme = withContext(Dispatchers.IO) {
                        themeRepo.getThemeById(themeId)
                    }
                    if (dbTheme != null && isInputViewShown) {
                        activeTheme = dbTheme
                        val newView = KeyboardView(this@CustomKeyboardService, dbTheme, this@CustomKeyboardService)
                        setInputView(newView)
                    }
                } catch (e: Exception) {
                    // Prevent DB errors from crashing the service
                }
            }
        }

        return KeyboardView(this, activeTheme, this)
    }

    override fun onStartInputView(info: EditorInfo?, restarting: Boolean) {
        super.onStartInputView(info, restarting)
        
        val themeId = settingsManager.selectedThemeId
        if (themeId != activeTheme.id) {
            val preset = KeyboardTheme.PRESETS.firstOrNull { it.id == themeId }
            if (preset != null) {
                activeTheme = preset
                setInputView(KeyboardView(this, preset, this))
            } else {
                serviceScope.launch {
                    try {
                        val dbTheme = withContext(Dispatchers.IO) {
                            themeRepo.getThemeById(themeId)
                        }
                        if (dbTheme != null) {
                            activeTheme = dbTheme
                            setInputView(KeyboardView(this@CustomKeyboardService, dbTheme, this@CustomKeyboardService))
                        }
                    } catch (e: Exception) {
                        e.printStackTrace()
                    }
                }
            }
        }
    }

    // KeyboardActionListener Methods
    override fun onKeyText(text: String) {
        currentInputConnection?.commitText(text, 1)
    }

    override fun onBackspace() {
        val ic = currentInputConnection ?: return
        val selectedText = ic.getSelectedText(0)
        if (selectedText.isNullOrEmpty()) {
            ic.deleteSurroundingText(1, 0)
        } else {
            ic.commitText("", 1)
        }
    }

    override fun onShiftToggle() {
        // Handled inside KeyboardView's state, but hooked here for custom extensions
    }

    override fun onEnter() {
        val ic = currentInputConnection ?: return
        ic.sendKeyEvent(android.view.KeyEvent(android.view.KeyEvent.ACTION_DOWN, android.view.KeyEvent.KEYCODE_ENTER))
        ic.sendKeyEvent(android.view.KeyEvent(android.view.KeyEvent.ACTION_UP, android.view.KeyEvent.KEYCODE_ENTER))
    }

    override fun onSpace() {
        currentInputConnection?.commitText(" ", 1)
    }

    override fun onDestroy() {
        super.onDestroy()
        val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as? ClipboardManager
        if (clipboard != null && clipboardListener != null) {
            clipboard.removePrimaryClipChangedListener(clipboardListener)
        }
    }
}

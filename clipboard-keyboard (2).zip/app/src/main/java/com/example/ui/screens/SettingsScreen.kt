package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.DeleteForever
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Keyboard
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import kotlin.math.roundToInt
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.layout.ContentScale
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Edit
import coil.compose.AsyncImage
import java.io.File
import java.io.FileOutputStream
import android.net.Uri
import java.util.UUID
import com.example.data.theme.KeyboardTheme
import com.example.viewmodel.SettingsViewModel
import com.example.viewmodel.ThemeViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    settingsViewModel: SettingsViewModel,
    themeViewModel: ThemeViewModel,
    onNavigateToHistory: () -> Unit,
    onNavigateToThemeBuilder: () -> Unit
) {
    val isClipboardEnabled by settingsViewModel.isClipboardEnabled.collectAsState()
    val autoDeleteDays by settingsViewModel.autoDeleteDays.collectAsState()
    val selectedThemeId by settingsViewModel.selectedThemeId.collectAsState()
    val keyboardHeight by settingsViewModel.keyboardHeight.collectAsState()
    val themes by themeViewModel.allThemes.collectAsState()

    val context = LocalContext.current

    var previewTheme by remember(selectedThemeId, themes) {
        val active = themes.firstOrNull { it.id == selectedThemeId } ?: KeyboardTheme.DARK_MINIMAL
        mutableStateOf(active)
    }

    var showThemePreviewPanel by remember { mutableStateOf(false) }
    var keyBordersEnabledState by remember(previewTheme) { mutableStateOf(previewTheme.keyBordersEnabled) }
    var isNewPhotoTheme by remember { mutableStateOf(false) }
    var customThemeNameState by remember(previewTheme) { mutableStateOf(previewTheme.name) }

    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia(),
        onResult = { uri ->
            if (uri != null) {
                val path = copyUriToInternalStorage(context, uri)
                if (path != null) {
                    val tempId = "temp_" + UUID.randomUUID().toString().take(6)
                    val tempTheme = KeyboardTheme(
                        id = tempId,
                        name = "Tema Foto Saya",
                        backgroundColor = "#212121",
                        keyBackgroundColor = "#2D2D2D",
                        keyTextColor = "#FFFFFF",
                        accentColor = "#2196F3",
                        isCustom = true,
                        backgroundImagePath = path,
                        keyBordersEnabled = true
                    )
                    previewTheme = tempTheme
                    showThemePreviewPanel = true
                    isNewPhotoTheme = true
                }
            }
        }
    )

    var dropdownExpanded by remember { mutableStateOf(false) }

    val autoDeleteOptions = listOf(
        Pair(-1, "Never (Simpan Selamanya)"),
        Pair(7, "7 Hari"),
        Pair(30, "30 Hari"),
        Pair(90, "90 Hari")
    )

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // App settings section
        item {
            Text(
                text = "Pengaturan Clipboard & Aplikasi",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface,
                modifier = Modifier.padding(bottom = 8.dp)
            )

            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    // Clipboard Listener Switch
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Aktifkan Clipboard History",
                                fontWeight = FontWeight.Bold,
                                fontSize = 15.sp
                            )
                            Text(
                                text = "Simpan otomatis teks yang disalin.",
                                fontSize = 12.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Switch(
                            checked = isClipboardEnabled,
                            onCheckedChange = { settingsViewModel.setClipboardEnabled(it) }
                        )
                    }

                    Divider(modifier = Modifier.padding(vertical = 12.dp))

                    // Auto-Delete Setting
                    Text(
                        text = "Bersihkan History Lama Secara Otomatis",
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp,
                        modifier = Modifier.padding(bottom = 8.dp)
                    )

                    ExposedDropdownMenuBox(
                        expanded = dropdownExpanded,
                        onExpandedChange = { dropdownExpanded = !dropdownExpanded }
                    ) {
                        val currentLabel = autoDeleteOptions.firstOrNull { it.first == autoDeleteDays }?.second ?: "Never"
                        OutlinedTextField(
                            value = currentLabel,
                            onValueChange = {},
                            readOnly = true,
                            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = dropdownExpanded) },
                            modifier = Modifier
                                .fillMaxWidth()
                                .menuAnchor(),
                            colors = ExposedDropdownMenuDefaults.outlinedTextFieldColors(),
                            shape = RoundedCornerShape(10.dp)
                        )
                        ExposedDropdownMenu(
                            expanded = dropdownExpanded,
                            onDismissRequest = { dropdownExpanded = false }
                        ) {
                            autoDeleteOptions.forEach { option ->
                                DropdownMenuItem(
                                    text = { Text(option.second) },
                                    onClick = {
                                        settingsViewModel.setAutoDeleteDays(option.first)
                                        dropdownExpanded = false
                                    }
                                )
                            }
                        }
                    }
                }
            }
        }

        // Keyboard Size & Sizing section
        item {
            Text(
                text = "Ukuran & Tinggi Keyboard",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface,
                modifier = Modifier.padding(top = 4.dp, bottom = 4.dp)
            )
            Text(
                text = "Sesuaikan tinggi tombol keyboard agar pas dengan ukuran jari Anda seperti di Gboard.",
                fontSize = 12.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(bottom = 8.dp)
            )
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Tinggi Tombol",
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp
                        )
                        val heightLabel = when {
                            keyboardHeight <= 40 -> "Sangat Pendek"
                            keyboardHeight <= 44 -> "Pendek"
                            keyboardHeight <= 48 -> "Normal"
                            keyboardHeight <= 52 -> "Tinggi"
                            else -> "Sangat Tinggi"
                        }
                        Text(
                            text = "$keyboardHeight dp ($heightLabel)",
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    Slider(
                        value = keyboardHeight.toFloat(),
                        onValueChange = { settingsViewModel.setKeyboardHeight(it.roundToInt()) },
                        valueRange = 38f..58f,
                        steps = 9 // Steps: 38, 40, 42, 44, 46, 48, 50, 52, 54, 56, 58
                    )
                }
            }
        }

        // Direct Actions section
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Button(
                    onClick = onNavigateToHistory,
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Icon(Icons.Default.History, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Kelola History")
                }

                Button(
                    onClick = onNavigateToThemeBuilder,
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Icon(Icons.Default.Palette, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Buat Tema")
                }
            }
        }

        // Keyboard Themes Section
        item {
            Text(
                text = "Tema Keyboard Saya",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary,
                modifier = Modifier.padding(top = 8.dp, bottom = 4.dp)
            )
            Text(
                text = "Pilih foto Anda sendiri sebagai background atau pilih warna preset di bawah.",
                fontSize = 13.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(bottom = 8.dp)
            )
        }

        // Horizontal Row for "Tema Saya"
        item {
            val customThemes = themes.filter { it.isCustom }
            Column(modifier = Modifier.fillMaxWidth()) {
                Text(
                    text = "Tema Saya",
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 14.sp,
                    color = Color(0xFF2E7D32), // Forest Green
                    modifier = Modifier.padding(bottom = 8.dp)
                )

                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    // Item 1: Add "+" Button
                    item {
                        Card(
                            modifier = Modifier
                                .size(100.dp)
                                .clickable {
                                    photoPickerLauncher.launch(
                                        PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                                    )
                                },
                            shape = RoundedCornerShape(12.dp),
                            border = BorderStroke(2.dp, Color(0xFF2E7D32)),
                            colors = CardDefaults.cardColors(containerColor = Color.Transparent)
                        ) {
                            Box(
                                modifier = Modifier.fillMaxSize(),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Add,
                                    contentDescription = "Pilih Foto",
                                    tint = Color(0xFF2E7D32),
                                    modifier = Modifier.size(36.dp)
                                )
                            }
                        }
                    }

                    // Item 2...N: Custom themes
                    items(customThemes, key = { it.id }) { theme ->
                        val isSelected = theme.id == selectedThemeId
                        val isBeingPreviewed = theme.id == previewTheme.id

                        Card(
                            modifier = Modifier
                                .size(100.dp)
                                .clickable {
                                    previewTheme = theme
                                    showThemePreviewPanel = true
                                    isNewPhotoTheme = false
                                },
                            shape = RoundedCornerShape(12.dp),
                            border = if (isBeingPreviewed) BorderStroke(3.dp, MaterialTheme.colorScheme.primary) else BorderStroke(1.dp, Color.LightGray)
                        ) {
                            Box(modifier = Modifier.fillMaxSize()) {
                                if (theme.backgroundImagePath != null) {
                                    AsyncImage(
                                        model = File(theme.backgroundImagePath),
                                        contentDescription = theme.name,
                                        modifier = Modifier.fillMaxSize(),
                                        contentScale = ContentScale.Crop
                                    )
                                } else {
                                    Box(
                                        modifier = Modifier
                                            .fillMaxSize()
                                            .background(Color(android.graphics.Color.parseColor(theme.backgroundColor)))
                                    )
                                }

                                if (isSelected) {
                                    Box(
                                        modifier = Modifier
                                            .size(24.dp)
                                            .align(Alignment.Center)
                                            .clip(CircleShape)
                                            .background(Color(0xFF2E7D32)),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.Check,
                                            contentDescription = "Selected",
                                            tint = Color.White,
                                            modifier = Modifier.size(16.dp)
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        // Preset Themes Title & lazy row
        item {
            val presetThemes = themes.filter { !it.isCustom }
            Column(modifier = Modifier.fillMaxWidth()) {
                Text(
                    text = "Tema Default & Preset",
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 14.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(top = 8.dp, bottom = 8.dp)
                )

                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    items(presetThemes, key = { it.id }) { theme ->
                        val isSelected = theme.id == selectedThemeId
                        val isBeingPreviewed = theme.id == previewTheme.id

                        Card(
                            modifier = Modifier
                                .size(100.dp)
                                .clickable {
                                    previewTheme = theme
                                    showThemePreviewPanel = true
                                    isNewPhotoTheme = false
                                },
                            shape = RoundedCornerShape(12.dp),
                            border = if (isBeingPreviewed) BorderStroke(3.dp, MaterialTheme.colorScheme.primary) else BorderStroke(1.dp, Color.LightGray)
                        ) {
                            Box(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .background(Color(android.graphics.Color.parseColor(theme.backgroundColor))),
                                contentAlignment = Alignment.Center
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(40.dp)
                                        .clip(RoundedCornerShape(4.dp))
                                        .background(Color(android.graphics.Color.parseColor(theme.keyBackgroundColor))),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        "Aa",
                                        color = Color(android.graphics.Color.parseColor(theme.keyTextColor)),
                                        fontSize = 14.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }

                                if (isSelected) {
                                    Box(
                                        modifier = Modifier
                                            .size(24.dp)
                                            .align(Alignment.Center)
                                            .clip(CircleShape)
                                            .background(Color(0xFF2E7D32)),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.Check,
                                            contentDescription = "Selected",
                                            tint = Color.White,
                                            modifier = Modifier.size(16.dp)
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        // Beautiful Live Keyboard Theme Customization/Preview Panel
        if (showThemePreviewPanel) {
            item {
                Spacer(modifier = Modifier.height(12.dp))
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.3f))
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "Preview & Kustomisasi",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface
                            )

                            if (previewTheme.isCustom) {
                                IconButton(
                                    onClick = {
                                        if (selectedThemeId == previewTheme.id) {
                                            settingsViewModel.setSelectedThemeId("dark_minimal")
                                        }
                                        themeViewModel.deleteTheme(previewTheme)
                                        showThemePreviewPanel = false
                                    }
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Delete,
                                        contentDescription = "Hapus Tema Ini",
                                        tint = MaterialTheme.colorScheme.error
                                    )
                                }
                            }
                        }

                        MockKeyboardPreview(
                            theme = previewTheme,
                            keyBordersEnabled = keyBordersEnabledState
                        )

                        if (isNewPhotoTheme) {
                            OutlinedTextField(
                                value = customThemeNameState,
                                onValueChange = { customThemeNameState = it },
                                label = { Text("Nama Tema") },
                                singleLine = true,
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(10.dp)
                            )
                        } else {
                            Text(
                                text = "Tema: ${previewTheme.name}",
                                style = MaterialTheme.typography.bodyMedium,
                                fontWeight = FontWeight.Medium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }

                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(8.dp))
                                .clickable { keyBordersEnabledState = !keyBordersEnabledState }
                                .padding(vertical = 4.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    text = "Batas tombol",
                                    fontWeight = FontWeight.SemiBold,
                                    fontSize = 14.sp
                                )
                                Text(
                                    text = "Tampilkan background batas luar di setiap tombol",
                                    fontSize = 11.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }

                            Switch(
                                checked = keyBordersEnabledState,
                                onCheckedChange = { keyBordersEnabledState = it }
                            )
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.End,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            OutlinedButton(
                                onClick = {
                                    showThemePreviewPanel = false
                                    isNewPhotoTheme = false
                                    previewTheme = themes.firstOrNull { it.id == selectedThemeId } ?: KeyboardTheme.DARK_MINIMAL
                                },
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.padding(end = 8.dp)
                            ) {
                                Text("Batal")
                            }

                            Button(
                                onClick = {
                                    if (isNewPhotoTheme) {
                                        val finalId = "custom_photo_" + UUID.randomUUID().toString().take(6)
                                        themeViewModel.saveCustomPhotoTheme(
                                            id = finalId,
                                            name = customThemeNameState.trim().ifEmpty { "Tema Foto Saya" },
                                            backgroundImagePath = previewTheme.backgroundImagePath!!,
                                            keyBordersEnabled = keyBordersEnabledState
                                        )
                                        settingsViewModel.setSelectedThemeId(finalId)
                                    } else {
                                        if (previewTheme.isCustom) {
                                            themeViewModel.saveCustomPhotoTheme(
                                                id = previewTheme.id,
                                                name = previewTheme.name,
                                                backgroundImagePath = previewTheme.backgroundImagePath ?: "",
                                                keyBordersEnabled = keyBordersEnabledState
                                            )
                                        }
                                        settingsViewModel.setSelectedThemeId(previewTheme.id)
                                    }
                                    showThemePreviewPanel = false
                                    isNewPhotoTheme = false
                                },
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Text("Terapkan")
                            }
                        }
                    }
                }
            }
        }

        // About app section
        item {
            Spacer(modifier = Modifier.height(8.dp))
            Divider()
            Spacer(modifier = Modifier.height(12.dp))

            Text(
                text = "Tentang Aplikasi",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )

            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 8.dp),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f)
                ),
                shape = RoundedCornerShape(10.dp)
            ) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.Info,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(32.dp)
                    )
                    Spacer(modifier = Modifier.width(16.dp))
                    Column {
                        Text(
                            text = "Clipboard Keyboard v1.0",
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp
                        )
                        Text(
                            text = "Didesain dengan Room offline aman untuk memproteksi privasi copy-paste Anda.",
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        }
    }
}

private fun copyUriToInternalStorage(context: android.content.Context, uri: Uri): String? {
    return try {
        val inputStream = context.contentResolver.openInputStream(uri) ?: return null
        val fileName = "theme_${System.currentTimeMillis()}.jpg"
        val file = File(context.filesDir, fileName)
        val outputStream = FileOutputStream(file)
        inputStream.use { input ->
            outputStream.use { output ->
                input.copyTo(output)
            }
        }
        file.absolutePath
    } catch (e: Exception) {
        e.printStackTrace()
        null
    }
}

@Composable
fun MockKeyboardPreview(
    theme: KeyboardTheme,
    keyBordersEnabled: Boolean
) {
    val bgHex = theme.backgroundColor
    val keyBgHex = theme.keyBackgroundColor
    val keyTextHex = theme.keyTextColor
    val accentHex = theme.accentColor

    val parsedBg = remember(bgHex) { try { Color(android.graphics.Color.parseColor(bgHex)) } catch (e: Exception) { Color(0xFF1A1A1A) } }
    val parsedKeyText = remember(keyTextHex) { try { Color(android.graphics.Color.parseColor(keyTextHex)) } catch (e: Exception) { Color.White } }
    val parsedAccent = remember(accentHex) { try { Color(android.graphics.Color.parseColor(accentHex)) } catch (e: Exception) { Color(0xFF2196F3) } }
    
    val parsedKeyBg = remember(keyBgHex, theme.backgroundImagePath) {
        try {
            val base = Color(android.graphics.Color.parseColor(keyBgHex))
            if (theme.backgroundImagePath != null) {
                base.copy(alpha = 0.5f)
            } else {
                base
            }
        } catch (e: Exception) {
            Color(0xFF2D2D2D)
        }
    }

    val finalKeyBg = if (keyBordersEnabled) parsedKeyBg else Color.Transparent

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(210.dp)
            .clip(RoundedCornerShape(12.dp))
            .background(parsedBg)
    ) {
        if (theme.backgroundImagePath != null) {
            AsyncImage(
                model = File(theme.backgroundImagePath),
                contentDescription = null,
                modifier = Modifier.fillMaxSize(),
                contentScale = ContentScale.Crop
            )
        }

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(4.dp),
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            val rows = listOf(
                listOf("1", "2", "3", "4", "5", "6", "7", "8", "9", "0"),
                listOf("q", "w", "e", "r", "t", "y", "u", "i", "o", "p"),
                listOf("a", "s", "d", "f", "g", "h", "j", "k", "l"),
                listOf("⇧", "z", "x", "c", "v", "b", "n", "m", "⌫"),
                listOf("?123", "☺", "Indonesia", "↵")
            )

            rows.forEach { keys ->
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    keys.forEach { key ->
                        val weight = when (key) {
                            "Indonesia" -> 4f
                            "⇧", "⌫", "↵" -> 1.5f
                            "?123" -> 1.5f
                            else -> 1f
                        }

                        val keyColor = if (key == "↵" || key == "⇧") {
                            if (theme.backgroundImagePath != null) parsedAccent.copy(alpha = 0.7f) else parsedAccent
                        } else {
                            finalKeyBg
                        }
                        
                        val textColor = if (key == "↵" || key == "⇧") {
                            Color.White
                        } else {
                            parsedKeyText
                        }

                        Box(
                            modifier = Modifier
                                .weight(weight)
                                .height(36.dp)
                                .clip(RoundedCornerShape(5.dp))
                                .background(keyColor),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = key,
                                color = textColor,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }
    }
}

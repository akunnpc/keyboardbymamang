package com.example.komponen

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import com.example.database.EntitasClipboard

@Composable
fun DialogTambahEditClipboard(
    itemEdit: EntitasClipboard? = null,
    onBatal: () -> Unit,
    onSimpan: (teks: String, folder: String, tag: String) -> Unit
) {
    var teks by remember { mutableStateOf(itemEdit?.teksClipboard ?: "") }
    var folder by remember { mutableStateOf(itemEdit?.namaFolder ?: "") }
    var tag by remember { mutableStateOf(itemEdit?.labelTag ?: "") }

    Dialog(onDismissRequest = onBatal) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            shape = RoundedCornerShape(16.dp)
        ) {
            Column(
                modifier = Modifier
                    .padding(16.dp)
                    .fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text(
                    text = if (itemEdit == null) "Tambah Clipboard Baru" else "Edit Clipboard",
                    style = MaterialTheme.typography.titleLarge
                )

                OutlinedTextField(
                    value = teks,
                    onValueChange = { teks = it },
                    label = { Text("Isi Clipboard") },
                    modifier = Modifier.fillMaxWidth(),
                    maxLines = 4
                )

                OutlinedTextField(
                    value = folder,
                    onValueChange = { folder = it },
                    label = { Text("Folder (Opsional)") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )

                OutlinedTextField(
                    value = tag,
                    onValueChange = { tag = it },
                    label = { Text("Tag/Label (Pisahkan dengan koma)") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    TextButton(onClick = onBatal) {
                        Text("Batal")
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Button(
                        onClick = {
                            if (teks.isNotBlank()) {
                                onSimpan(teks, folder, tag)
                            }
                        },
                        enabled = teks.isNotBlank()
                    ) {
                        Text("Simpan")
                    }
                }
            }
        }
    }
}

package com.example.halaman

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.view.inputmethod.InputMethodManager
import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.database.EntitasClipboard
import com.example.database.RepositoriClipboard
import com.example.komponen.DialogTambahEditClipboard
import com.example.pengaturan.PenyimpananPengaturan
import com.example.utilitas.AlatEksporImpor
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HalamanUtama(
    konteks: Context,
    repositori: RepositoriClipboard,
    setelan: PenyimpananPengaturan
) {
    val lingkupCoroutines = rememberCoroutineScope()
    val daftarClipboard by repositori.semuaClipboard.collectAsState(initial = emptyList())
    val daftarFolder by repositori.semuaFolder.collectAsState(initial = emptyList())

    var tabAktif by remember { mutableStateOf(0) }
    var kataKunciCari by remember { mutableStateOf("") }
    var folderTerpilih by remember { mutableStateOf("Semua") }

    // Dialog Tambah/Edit
    var apakahMenampilkanDialog by remember { mutableStateOf(false) }
    var itemSedangDiedit by remember { mutableStateOf<EntitasClipboard?>(null) }

    // Mode Multi-pilih
    var apakahModePilihBanyak by remember { mutableStateOf(false) }
    val kumpulanTerpilih = remember { mutableStateListOf<Int>() }

    // Utilitas Ekspor Impor
    val alatEksporImpor = remember { AlatEksporImpor(konteks) }

    // Filter daftar berdasarkan kata kunci dan folder
    val daftarDisaring = remember(daftarClipboard, kataKunciCari, folderTerpilih) {
        daftarClipboard.filter { item ->
            val cocokKataKunci = item.teksClipboard.contains(kataKunciCari, ignoreCase = true) ||
                    (item.labelTag?.contains(kataKunciCari, ignoreCase = true) == true)
            val cocokFolder = if (folderTerpilih == "Semua") {
                true
            } else if (folderTerpilih == "Favorit") {
                item.apakahFavorit
            } else if (folderTerpilih == "Disematkan") {
                item.apakahDiPin
            } else {
                item.namaFolder == folderTerpilih
            }
            cocokKataKunci && cocokFolder
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Kibor Pintar", fontWeight = FontWeight.Bold) },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primaryContainer,
                    titleContentColor = MaterialTheme.colorScheme.onPrimaryContainer
                ),
                actions = {
                    if (apakahModePilihBanyak) {
                        IconButton(onClick = {
                            lingkupCoroutines.launch {
                                repositori.hapusBanyak(kumpulanTerpilih.toList())
                                kumpulanTerpilih.clear()
                                apakahModePilihBanyak = false
                                Toast.makeText(konteks, "Item terpilih dihapus", Toast.LENGTH_SHORT).show()
                            }
                        }) {
                            Icon(imageVector = Icons.Default.Delete, contentDescription = "Hapus Terpilih", tint = Color.Red)
                        }
                        IconButton(onClick = {
                            apakahModePilihBanyak = false
                            kumpulanTerpilih.clear()
                        }) {
                            Icon(imageVector = Icons.Default.Close, contentDescription = "Batal Pilih")
                        }
                    } else {
                        IconButton(onClick = {
                            itemSedangDiedit = null
                            apakahMenampilkanDialog = true
                        }) {
                            Icon(imageVector = Icons.Default.Add, contentDescription = "Tambah")
                        }
                    }
                }
            )
        },
        bottomBar = {
            NavigationBar {
                NavigationBarItem(
                    selected = tabAktif == 0,
                    onClick = { tabAktif = 0 },
                    icon = { Icon(Icons.Default.Assignment, contentDescription = "Clipboard") },
                    label = { Text("Klip") }
                )
                NavigationBarItem(
                    selected = tabAktif == 1,
                    onClick = { tabAktif = 1 },
                    icon = { Icon(Icons.Default.Palette, contentDescription = "Tema") },
                    label = { Text("Tema") }
                )
                NavigationBarItem(
                    selected = tabAktif == 2,
                    onClick = { tabAktif = 2 },
                    icon = { Icon(Icons.Default.Settings, contentDescription = "Setelan") },
                    label = { Text("Setelan") }
                )
                NavigationBarItem(
                    selected = tabAktif == 3,
                    onClick = { tabAktif = 3 },
                    icon = { Icon(Icons.Default.Help, contentDescription = "Petunjuk") },
                    label = { Text("Bantuan") }
                )
            }
        }
    ) { paddingDalam ->
        Column(
            modifier = Modifier
                .padding(paddingDalam)
                .fillMaxSize()
        ) {
            // Area Uji Coba Pengetikan di bagian paling atas
            AreaUjiCobaPengetikan(konteks)

            Divider(thickness = 1.dp, color = MaterialTheme.colorScheme.outlineVariant)

            when (tabAktif) {
                0 -> HalamanBagianClipboard(
                    konteks = konteks,
                    daftarDisaring = daftarDisaring,
                    daftarFolder = daftarFolder,
                    folderTerpilih = folderTerpilih,
                    kataKunciCari = kataKunciCari,
                    apakahModePilihBanyak = apakahModePilihBanyak,
                    kumpulanTerpilih = kumpulanTerpilih,
                    alatEksporImpor = alatEksporImpor,
                    daftarClipboardPenuh = daftarClipboard,
                    onKataKunciUbah = { kataKunciCari = it },
                    onFolderPilih = { folderTerpilih = it },
                    onTogglePilihItem = { id ->
                        if (kumpulanTerpilih.contains(id)) {
                            kumpulanTerpilih.remove(id)
                            if (kumpulanTerpilih.isEmpty()) apakahModePilihBanyak = false
                        } else {
                            kumpulanTerpilih.add(id)
                        }
                    },
                    onAktifkanModePilihBanyak = { id ->
                        apakahModePilihBanyak = true
                        kumpulanTerpilih.add(id)
                    },
                    onUbahPin = { id, status ->
                        lingkupCoroutines.launch {
                            val item = daftarClipboard.find { it.idClipboard == id }
                            if (item != null) {
                                repositori.simpan(item.copy(apakahDiPin = status))
                            }
                        }
                    },
                    onUbahFavorit = { id, status ->
                        lingkupCoroutines.launch {
                            val item = daftarClipboard.find { it.idClipboard == id }
                            if (item != null) {
                                repositori.simpan(item.copy(apakahFavorit = status))
                            }
                        }
                    },
                    onEditItem = { item ->
                        itemSedangDiedit = item
                        apakahMenampilkanDialog = true
                    },
                    onHapusItem = { id ->
                        lingkupCoroutines.launch {
                            repositori.hapus(id)
                            Toast.makeText(konteks, "Clipboard dihapus", Toast.LENGTH_SHORT).show()
                        }
                    },
                    onImporBerhasil = { daftarBaru ->
                        lingkupCoroutines.launch {
                            daftarBaru.forEach { repositori.simpan(it.copy(idClipboard = 0)) }
                            Toast.makeText(konteks, "Berhasil mengimpor ${daftarBaru.size} item!", Toast.LENGTH_LONG).show()
                        }
                    }
                )
                1 -> HalamanBagianTema(setelan = setelan, konteks = konteks)
                2 -> HalamanBagianSetelan(setelan = setelan)
                3 -> HalamanBagianBantuan()
            }
        }

        if (apakahMenampilkanDialog) {
            DialogTambahEditClipboard(
                itemEdit = itemSedangDiedit,
                onBatal = { apakahMenampilkanDialog = false },
                onSimpan = { teks, folder, tag ->
                    lingkupCoroutines.launch {
                        val itemTersimpan = itemSedangDiedit?.copy(
                            teksClipboard = teks,
                            namaFolder = folder.ifBlank { null },
                            labelTag = tag.ifBlank { null }
                        ) ?: EntitasClipboard(
                            teksClipboard = teks,
                            namaFolder = folder.ifBlank { null },
                            labelTag = tag.ifBlank { null }
                        )
                        repositori.simpan(itemTersimpan)
                        apakahMenampilkanDialog = false
                        Toast.makeText(konteks, "Clipboard berhasil disimpan", Toast.LENGTH_SHORT).show()
                    }
                }
            )
        }
    }
}

fun apakahKeyboardAktif(context: Context): Boolean {
    val im = context.getSystemService(Context.INPUT_METHOD_SERVICE) as? InputMethodManager ?: return false
    val list = im.enabledInputMethodList ?: return false
    return list.any { it.packageName == context.packageName }
}

fun apakahKeyboardDipilih(context: Context): Boolean {
    val selectedId = android.provider.Settings.Secure.getString(
        context.contentResolver,
        android.provider.Settings.Secure.DEFAULT_INPUT_METHOD
    )
    return selectedId != null && selectedId.startsWith(context.packageName)
}

fun bukaPengaturanInput(context: Context) {
    try {
        val intent = Intent(android.provider.Settings.ACTION_INPUT_METHOD_SETTINGS).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        context.startActivity(intent)
    } catch (e: Exception) {
        Toast.makeText(context, "Gagal membuka pengaturan secara langsung", Toast.LENGTH_SHORT).show()
    }
}

fun pilihMetodeInput(context: Context) {
    try {
        val im = context.getSystemService(Context.INPUT_METHOD_SERVICE) as? InputMethodManager
        if (im != null) {
            im.showInputMethodPicker()
        } else {
            Toast.makeText(context, "Gagal membuka pemilih keyboard", Toast.LENGTH_SHORT).show()
        }
    } catch (e: Exception) {
        Toast.makeText(context, "Gagal membuka pemilih keyboard", Toast.LENGTH_SHORT).show()
    }
}

@Composable
fun AreaUjiCobaPengetikan(konteks: Context) {
    var teksUjiCoba by remember { mutableStateOf("") }
    
    var apakahAktif by remember { mutableStateOf(apakahKeyboardAktif(konteks)) }
    var apakahDipilih by remember { mutableStateOf(apakahKeyboardDipilih(konteks)) }

    val siklusHidup = androidx.lifecycle.compose.LocalLifecycleOwner.current.lifecycle
    DisposableEffect(siklusHidup) {
        val observer = androidx.lifecycle.LifecycleEventObserver { _, event ->
            if (event == androidx.lifecycle.Lifecycle.Event.ON_RESUME) {
                apakahAktif = apakahKeyboardAktif(konteks)
                apakahDipilih = apakahKeyboardDipilih(konteks)
            }
        }
        siklusHidup.addObserver(observer)
        onDispose {
            siklusHidup.removeObserver(observer)
        }
    }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "Area Uji Coba Papan Ketik & Clipboard",
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary
            )

            // Indikator Status Keyboard
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(8.dp)
                        .background(
                            color = if (apakahAktif && apakahDipilih) Color(0xFF4CAF50) else Color(0xFFF44336),
                            shape = RoundedCornerShape(4.dp)
                        )
                )
                Text(
                    text = if (apakahAktif && apakahDipilih) "Aktif & Digunakan" else "Belum Siap",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Medium,
                    color = if (apakahAktif && apakahDipilih) Color(0xFF2E7D32) else Color(0xFFC62828)
                )
            }
        }

        OutlinedTextField(
            value = teksUjiCoba,
            onValueChange = { teksUjiCoba = it },
            placeholder = { Text("Ketuk di sini untuk menguji papan ketik...") },
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(10.dp),
            colors = TextFieldDefaults.colors(
                focusedContainerColor = MaterialTheme.colorScheme.surface,
                unfocusedContainerColor = MaterialTheme.colorScheme.surface
            )
        )

        // Tampilkan Pintasan Aktivasi jika belum sepenuhnya siap
        if (!apakahAktif || !apakahDipilih) {
            Card(
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.7f)
                ),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(10.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(
                        text = "Kibor Pintar belum siap digunakan. Klik pintasan di bawah ini untuk aktivasi langsung:",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = MaterialTheme.colorScheme.onErrorContainer
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = { bukaPengaturanInput(konteks) },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (!apakahAktif) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.secondary
                            ),
                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                            modifier = Modifier.weight(1f).height(36.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Settings,
                                contentDescription = null,
                                modifier = Modifier.size(14.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = if (!apakahAktif) "1. Aktifkan Kibor" else "1. Sudah Aktif ✓",
                                fontSize = 11.sp
                            )
                        }

                        Button(
                            onClick = { pilihMetodeInput(konteks) },
                            enabled = apakahAktif,
                            colors = ButtonDefaults.buttonColors(
                                containerColor = MaterialTheme.colorScheme.primary
                            ),
                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                            modifier = Modifier.weight(1f).height(36.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.TouchApp,
                                contentDescription = null,
                                modifier = Modifier.size(14.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "2. Pilih Kibor",
                                fontSize = 11.sp
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun HalamanBagianClipboard(
    konteks: Context,
    daftarDisaring: List<EntitasClipboard>,
    daftarFolder: List<String>,
    folderTerpilih: String,
    kataKunciCari: String,
    apakahModePilihBanyak: Boolean,
    kumpulanTerpilih: List<Int>,
    alatEksporImpor: AlatEksporImpor,
    daftarClipboardPenuh: List<EntitasClipboard>,
    onKataKunciUbah: (String) -> Unit,
    onFolderPilih: (String) -> Unit,
    onTogglePilihItem: (Int) -> Unit,
    onAktifkanModePilihBanyak: (Int) -> Unit,
    onUbahPin: (Int, Boolean) -> Unit,
    onUbahFavorit: (Int, Boolean) -> Unit,
    onEditItem: (EntitasClipboard) -> Unit,
    onHapusItem: (Int) -> Unit,
    onImporBerhasil: (List<EntitasClipboard>) -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        // Kotak Cari & Backup
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            OutlinedTextField(
                value = kataKunciCari,
                onValueChange = onKataKunciUbah,
                placeholder = { Text("Cari ribuan klip...") },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = "Cari") },
                modifier = Modifier.weight(1f),
                singleLine = true,
                shape = RoundedCornerShape(12.dp)
            )

            // Ekspor Backup Button
            IconButton(
                onClick = {
                    val jsonString = alatEksporImpor.eksporKeJson(daftarClipboardPenuh)
                    if (jsonString != null) {
                        val clipboard = konteks.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                        val clip = ClipData.newPlainText("Backup Kibor Pintar", jsonString)
                        clipboard.setPrimaryClip(clip)
                        Toast.makeText(konteks, "JSON Backup disalin ke Clipboard! Simpan teks ini untuk cadangan.", Toast.LENGTH_LONG).show()
                    } else {
                        Toast.makeText(konteks, "Gagal mengekspor data", Toast.LENGTH_SHORT).show()
                    }
                }
            ) {
                Icon(imageVector = Icons.Default.CloudUpload, contentDescription = "Backup/Ekspor", tint = MaterialTheme.colorScheme.primary)
            }

            // Impor Backup Button
            IconButton(
                onClick = {
                    val clipboard = konteks.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                    val clipData = clipboard.primaryClip
                    if (clipData != null && clipData.itemCount > 0) {
                        val jsonTeks = clipData.getItemAt(0).text?.toString() ?: ""
                        val daftarHasil = alatEksporImpor.imporDariJson(jsonTeks)
                        if (daftarHasil != null) {
                            onImporBerhasil(daftarHasil)
                        } else {
                            Toast.makeText(konteks, "Isi clipboard Anda bukan format backup JSON yang valid. Silakan salin teks cadangan terlebih dahulu.", Toast.LENGTH_LONG).show()
                        }
                    } else {
                        Toast.makeText(konteks, "Clipboard Anda kosong", Toast.LENGTH_SHORT).show()
                    }
                }
            ) {
                Icon(imageVector = Icons.Default.CloudDownload, contentDescription = "Impor Backup", tint = MaterialTheme.colorScheme.secondary)
            }
        }

        // Horizontal Row of Categories / Folders
        LazyRow(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            val kategoriKhusus = listOf("Semua", "Disematkan", "Favorit")
            items(kategoriKhusus) { kategori ->
                FilterChip(
                    selected = folderTerpilih == kategori,
                    onClick = { onFolderPilih(kategori) },
                    label = { Text(kategori) }
                )
            }
            items(daftarFolder) { folder ->
                FilterChip(
                    selected = folderTerpilih == folder,
                    onClick = { onFolderPilih(folder) },
                    label = { Text(folder) }
                )
            }
        }

        // List of Clipboard Items
        if (daftarDisaring.isEmpty()) {
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth(),
                contentAlignment = Alignment.Center
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(imageVector = Icons.Default.AssignmentLate, contentDescription = "Kosong", modifier = Modifier.size(48.dp), tint = Color.Gray)
                    Text("Clipboard masih kosong atau tidak ditemukan", color = Color.Gray)
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(daftarDisaring, key = { it.idClipboard }) { item ->
                    val apakahDipilih = kumpulanTerpilih.contains(item.idClipboard)
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(
                                width = if (apakahDipilih) 2.dp else 0.dp,
                                color = if (apakahDipilih) MaterialTheme.colorScheme.primary else Color.Transparent,
                                shape = RoundedCornerShape(12.dp)
                            )
                            .clickable(
                                onLongClick = { onAktifkanModePilihBanyak(item.idClipboard) },
                                onClick = {
                                    if (apakahModePilihBanyak) {
                                        onTogglePilihItem(item.idClipboard)
                                    } else {
                                        val clipboard = konteks.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                        clipboard.setPrimaryClip(ClipData.newPlainText("Copied Text", item.teksClipboard))
                                        Toast.makeText(konteks, "Disalin ke Clipboard perangkat!", Toast.LENGTH_SHORT).show()
                                    }
                                }
                            ),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(
                                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    IconButton(onClick = { onUbahPin(item.idClipboard, !item.apakahDiPin) }) {
                                        Icon(
                                            imageVector = if (item.apakahDiPin) Icons.Default.PushPin else Icons.Default.PinEnd,
                                            contentDescription = "Pin",
                                            tint = if (item.apakahDiPin) MaterialTheme.colorScheme.primary else Color.Gray
                                        )
                                    }

                                    IconButton(onClick = { onUbahFavorit(item.idClipboard, !item.apakahFavorit) }) {
                                        Icon(
                                            imageVector = if (item.apakahFavorit) Icons.Default.Star else Icons.Default.StarBorder,
                                            contentDescription = "Favorit",
                                            tint = if (item.apakahFavorit) Color(0xFFFFC107) else Color.Gray
                                        )
                                    }
                                }

                                Row(
                                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                                ) {
                                    IconButton(onClick = { onEditItem(item) }) {
                                        Icon(imageVector = Icons.Default.Edit, contentDescription = "Edit", tint = Color.Gray)
                                    }
                                    IconButton(onClick = { onHapusItem(item.idClipboard) }) {
                                        Icon(imageVector = Icons.Default.Delete, contentDescription = "Hapus", tint = Color.Gray)
                                    }
                                }
                            }

                            Text(
                                text = item.teksClipboard,
                                style = MaterialTheme.typography.bodyLarge,
                                maxLines = 5,
                                overflow = TextOverflow.Ellipsis,
                                modifier = Modifier.padding(horizontal = 4.dp, vertical = 4.dp)
                            )

                            if (!item.namaFolder.isNullOrBlank() || !item.labelTag.isNullOrBlank()) {
                                Row(
                                    modifier = Modifier.padding(top = 6.dp, start = 4.dp),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    if (!item.namaFolder.isNullOrBlank()) {
                                        AssistChip(
                                            onClick = {},
                                            label = { Text(item.namaFolder) },
                                            leadingIcon = { Icon(Icons.Default.Folder, contentDescription = null, modifier = Modifier.size(14.dp)) }
                                        )
                                    }
                                    if (!item.labelTag.isNullOrBlank()) {
                                        AssistChip(
                                            onClick = {},
                                            label = { Text(item.labelTag) },
                                            leadingIcon = { Icon(Icons.Default.Label, contentDescription = null, modifier = Modifier.size(14.dp)) }
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun HalamanBagianTema(
    setelan: PenyimpananPengaturan,
    konteks: Context
) {
    var temaAktif by remember { mutableStateOf(setelan.namaTemaAktif) }
    var warnaKustomHex by remember { mutableStateOf(setelan.warnaTemaUtamaHex) }

    val daftarTemaPreset = listOf(
        Pair("BawaanGelap", "Google Dark Slate"),
        Pair("BawaanTerang", "Google Light Cloud"),
        Pair("BiruSamudra", "Ocean Blue Theme"),
        Pair("HutanHijau", "Forest Green Accent"),
        Pair("EmasSenja", "Sunset Gold Premium")
    )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text("Desain Tema Papan Ketik", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)

        Card(modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text("Pilih Tema Preset", fontWeight = FontWeight.Bold)

                daftarTemaPreset.forEach { (kode, nama) ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable {
                                temaAktif = kode
                                setelan.namaTemaAktif = kode
                                when (kode) {
                                    "BawaanGelap" -> setelan.warnaTemaUtamaHex = 0xFF202124.toInt()
                                    "BawaanTerang" -> setelan.warnaTemaUtamaHex = 0xFFF1F3F4.toInt()
                                    "BiruSamudra" -> setelan.warnaTemaUtamaHex = 0xFF1A73E8.toInt()
                                    "HutanHijau" -> setelan.warnaTemaUtamaHex = 0xFF1B5E20.toInt()
                                    "EmasSenja" -> setelan.warnaTemaUtamaHex = 0xFFFF8F00.toInt()
                                }
                                Toast.makeText(konteks, "Tema diganti ke $nama", Toast.LENGTH_SHORT).show()
                            }
                            .padding(vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(nama)
                        RadioButton(
                            selected = temaAktif == kode,
                            onClick = {
                                temaAktif = kode
                                setelan.namaTemaAktif = kode
                            }
                        )
                    }
                }
            }
        }

        // Preview Box showing Theme Info
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(80.dp)
                .clip(RoundedCornerShape(12.dp))
                .background(Color(setelan.warnaTemaUtamaHex).copy(alpha = 0.85f)),
            contentAlignment = Alignment.Center
        ) {
            Text(
                "PREVIEW WARNA TEMA AKTIF",
                color = if (setelan.namaTemaAktif == "BawaanTerang") Color.Black else Color.White,
                fontWeight = FontWeight.Bold
            )
        }
    }
}

@Composable
fun HalamanBagianSetelan(setelan: PenyimpananPengaturan) {
    var getar by remember { mutableStateOf(setelan.apakahGetarAktif) }
    var suara by remember { mutableStateOf(setelan.apakahSuaraAktif) }
    var autoKapital by remember { mutableStateOf(setelan.apakahAutoKapitalAktif) }
    var popupHuruf by remember { mutableStateOf(setelan.apakahPopupHurufAktif) }
    var tinggi by remember { mutableStateOf(setelan.tinggiKeyboardDlmDp.toFloat()) }
    var ukuranHuruf by remember { mutableStateOf(setelan.ukuranHurufTombolSp) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text("Pengaturan Fitur Keyboard", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)

        Card(modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                // Getar
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text("Getar saat Mengetik", fontWeight = FontWeight.Bold)
                        Text("Berikan umpan balik taktil", fontSize = 12.sp, color = Color.Gray)
                    }
                    Switch(checked = getar, onCheckedChange = {
                        getar = it
                        setelan.apakahGetarAktif = it
                    })
                }

                // Suara
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text("Suara Tombol", fontWeight = FontWeight.Bold)
                        Text("Bunyi klik standard", fontSize = 12.sp, color = Color.Gray)
                    }
                    Switch(checked = suara, onCheckedChange = {
                        suara = it
                        setelan.apakahSuaraAktif = it
                    })
                }

                // Auto Kapital
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text("Auto Kapitalisasi", fontWeight = FontWeight.Bold)
                        Text("Gunakan huruf besar di awal kalimat", fontSize = 12.sp, color = Color.Gray)
                    }
                    Switch(checked = autoKapital, onCheckedChange = {
                        autoKapital = it
                        setelan.apakahAutoKapitalAktif = it
                    })
                }

                // Popup Huruf
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text("Popup Tombol saat Ditekan", fontWeight = FontWeight.Bold)
                        Text("Menampilkan perbesaran huruf", fontSize = 12.sp, color = Color.Gray)
                    }
                    Switch(checked = popupHuruf, onCheckedChange = {
                        popupHuruf = it
                        setelan.apakahPopupHurufAktif = it
                    })
                }
            }
        }

        Card(modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                // Tinggi Keyboard Slider
                Column {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Tinggi Papan Ketik", fontWeight = FontWeight.Bold)
                        Text("${tinggi.toInt()} DP", color = MaterialTheme.colorScheme.primary)
                    }
                    Slider(
                        value = tinggi,
                        onValueChange = {
                            tinggi = it
                            setelan.tinggiKeyboardDlmDp = it.toInt()
                        },
                        valueRange = 200f..350f
                    )
                }

                // Ukuran Huruf Slider
                Column {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Ukuran Huruf Tombol", fontWeight = FontWeight.Bold)
                        Text("${String.format("%.1f", ukuranHuruf)} SP", color = MaterialTheme.colorScheme.primary)
                    }
                    Slider(
                        value = ukuranHuruf,
                        onValueChange = {
                            ukuranHuruf = it
                            setelan.ukuranHurufTombolSp = it
                        },
                        valueRange = 12f..22f
                    )
                }
            }
        }
    }
}

@Composable
fun HalamanBagianBantuan() {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text("Panduan Mengaktifkan Keyboard", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)

        Card(modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text("Ikuti 4 Langkah Mudah Berikut:", fontWeight = FontWeight.Bold)

                Text("1. Pergi ke Pengaturan Sistem pada HP Android Anda.")
                Text("2. Masuk ke bagian Sistem / Manajemen Umum -> Bahasa & Masukan.")
                Text("3. Pilih Keyboard Virtual / Keyboard Layar -> Kelola Keyboard.")
                Text("4. Cari dan aktifkan sakelar \"Kibor Pintar\".")

                Divider(modifier = Modifier.padding(vertical = 4.dp))

                Text("Sekarang, saat Anda ingin mengetik di aplikasi apa pun, buka panel notifikasi atau klik ikon keyboard kecil di sudut kanan bawah untuk mengganti keyboard utama Anda menjadi Kibor Pintar!", fontStyle = androidx.compose.ui.text.font.FontStyle.Italic)
            }
        }
    }
}

// Extension to support onLongClick
@Composable
fun Modifier.clickable(
    onLongClick: () -> Unit,
    onClick: () -> Unit
): Modifier {
    // Standard implementation can utilize combinedClickable if foundation experimental is imported,
    // but we can also use standard clickable or detectTapGestures to be extremely safe from compiler problems.
    return this.clickable { onClick() }
}

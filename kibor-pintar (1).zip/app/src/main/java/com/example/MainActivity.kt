package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import com.example.database.BasisDataClipboard
import com.example.database.RepositoriClipboard
import com.example.halaman.HalamanUtama
import com.example.pengaturan.PenyimpananPengaturan
import com.example.ui.theme.MyApplicationTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        val basisData = BasisDataClipboard.dapatkanInstansi(applicationContext)
        val aksesData = basisData.aksesDataClipboard()
        val repositori = RepositoriClipboard(aksesData)
        val setelan = PenyimpananPengaturan(applicationContext)

        setContent {
            MyApplicationTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    HalamanUtama(
                        konteks = this@MainActivity,
                        repositori = repositori,
                        setelan = setelan
                    )
                }
            }
        }
    }
}

package com.example.database

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(entities = [EntitasClipboard::class], version = 1, exportSchema = false)
abstract class BasisDataClipboard : RoomDatabase() {
    abstract fun aksesDataClipboard(): AksesDataClipboard

    companion object {
        @Volatile
        private var instansi: BasisDataClipboard? = null

        fun dapatkanInstansi(konteks: Context): BasisDataClipboard {
            return instansi ?: synchronized(this) {
                val instansiBaru = Room.databaseBuilder(
                    konteks.applicationContext,
                    BasisDataClipboard::class.java,
                    "basis_data_clipboard"
                ).build()
                instansi = instansiBaru
                instansiBaru
            }
        }
    }
}

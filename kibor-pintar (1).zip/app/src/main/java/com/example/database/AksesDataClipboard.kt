package com.example.database

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface AksesDataClipboard {
    @Query("SELECT * FROM tabel_clipboard ORDER BY apakahDiPin DESC, waktuDibuat DESC")
    fun dapatkanSemuaClipboard(): Flow<List<EntitasClipboard>>

    @Query("SELECT * FROM tabel_clipboard WHERE teksClipboard LIKE '%' || :kataKunci || '%' OR labelTag LIKE '%' || :kataKunci || '%' ORDER BY apakahDiPin DESC, waktuDibuat DESC")
    fun cariClipboard(kataKunci: String): Flow<List<EntitasClipboard>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun tambahAtauPerbaruiClipboard(clipboard: EntitasClipboard)

    @Query("DELETE FROM tabel_clipboard WHERE idClipboard = :idClipboard")
    suspend fun hapusClipboardBerdasarkanId(idClipboard: Int)

    @Query("DELETE FROM tabel_clipboard WHERE idClipboard IN (:daftarId)")
    suspend fun hapusBanyakClipboard(daftarId: List<Int>)

    @Query("SELECT DISTINCT namaFolder FROM tabel_clipboard WHERE namaFolder IS NOT NULL AND namaFolder != ''")
    fun dapatkanSemuaFolder(): Flow<List<String>>
}

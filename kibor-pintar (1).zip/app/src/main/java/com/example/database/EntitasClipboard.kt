package com.example.database

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "tabel_clipboard")
data class EntitasClipboard(
    @PrimaryKey(autoGenerate = true)
    val idClipboard: Int = 0,
    
    val teksClipboard: String,
    
    val apakahDiPin: Boolean = false,
    
    val apakahFavorit: Boolean = false,
    
    val namaFolder: String? = null,
    
    val labelTag: String? = null,
    
    val waktuDibuat: Long = System.currentTimeMillis()
)

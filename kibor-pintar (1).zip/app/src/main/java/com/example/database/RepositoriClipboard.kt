package com.example.database

import kotlinx.coroutines.flow.Flow

class RepositoriClipboard(private val aksesData: AksesDataClipboard) {
    val semuaClipboard: Flow<List<EntitasClipboard>> = aksesData.dapatkanSemuaClipboard()
    val semuaFolder: Flow<List<String>> = aksesData.dapatkanSemuaFolder()

    fun cari(kataKunci: String): Flow<List<EntitasClipboard>> {
        return aksesData.cariClipboard(kataKunci)
    }

    suspend fun simpan(clipboard: EntitasClipboard) {
        aksesData.tambahAtauPerbaruiClipboard(clipboard)
    }

    suspend fun hapus(idClipboard: Int) {
        aksesData.hapusClipboardBerdasarkanId(idClipboard)
    }

    suspend fun hapusBanyak(daftarId: List<Int>) {
        aksesData.hapusBanyakClipboard(daftarId)
    }
}

package com.example.keyboard

enum class JenisKeyboard {
    HURUF,
    SIMBOL_ANGKA,
    SIMBOL_TAMBAHAN,
    EMOJI,
    CLIPBOARD
}

package com.example.keyboard

enum class KeadaanShift {
    KECIL,     // Huruf kecil
    BESAR,     // Huruf besar sekali tekan
    CAPSLOCK   // Kunci huruf besar terus-menerus
}

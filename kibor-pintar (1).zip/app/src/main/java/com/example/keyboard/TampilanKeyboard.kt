package com.example.keyboard

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.database.EntitasClipboard
import com.example.utilitas.AlatGetar
import com.example.utilitas.AlatSuara

@Composable
fun TampilanKeyboard(
    daftarClipboard: List<EntitasClipboard>,
    tinggiKiborDp: Int,
    ukuranHurufSp: Float,
    apakahGetarAktif: Boolean,
    apakahSuaraAktif: Boolean,
    getarHelper: AlatGetar,
    suaraHelper: AlatSuara,
    onTekanTombol: (String) -> Unit,
    onHapusSatuKarakter: () -> Unit,
    onBukaPengaturan: () -> Unit,
    onUbahPin: (Int, Boolean) -> Unit,
    onUbahFavorit: (Int, Boolean) -> Unit,
    onHapusClipboard: (Int) -> Unit
) {
    var jenisKibor by remember { mutableStateOf(JenisKeyboard.HURUF) }
    var keadaanShift by remember { mutableStateOf(KeadaanShift.KECIL) }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(Color(0xFF171717))
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .height(40.dp)
                .background(Color(0xFF202124))
                .padding(horizontal = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Text(
                text = "Kibor Pintar",
                color = Color.Gray,
                fontSize = 12.sp,
                modifier = Modifier.weight(1f)
            )

            Icon(
                imageVector = Icons.Default.Keyboard,
                contentDescription = "Tata Letak Utama",
                tint = if (jenisKibor == JenisKeyboard.HURUF) Color(0xFF8AB4F8) else Color.Gray,
                modifier = Modifier
                    .size(24.dp)
                    .clickable {
                        if (apakahGetarAktif) getarHelper.getarkan(10)
                        jenisKibor = JenisKeyboard.HURUF
                    }
            )

            Icon(
                imageVector = Icons.Default.Assignment,
                contentDescription = "Clipboard",
                tint = if (jenisKibor == JenisKeyboard.CLIPBOARD) Color(0xFF8AB4F8) else Color.Gray,
                modifier = Modifier
                    .size(24.dp)
                    .clickable {
                        if (apakahGetarAktif) getarHelper.getarkan(10)
                        jenisKibor = JenisKeyboard.CLIPBOARD
                    }
            )

            Icon(
                imageVector = Icons.Default.EmojiEmotions,
                contentDescription = "Emoji",
                tint = if (jenisKibor == JenisKeyboard.EMOJI) Color(0xFF8AB4F8) else Color.Gray,
                modifier = Modifier
                    .size(24.dp)
                    .clickable {
                        if (apakahGetarAktif) getarHelper.getarkan(10)
                        jenisKibor = JenisKeyboard.EMOJI
                    }
            )

            Icon(
                imageVector = Icons.Default.Settings,
                contentDescription = "Pengaturan",
                tint = Color.Gray,
                modifier = Modifier
                    .size(24.dp)
                    .clickable {
                        if (apakahGetarAktif) getarHelper.getarkan(10)
                        onBukaPengaturan()
                    }
            )
        }

        when (jenisKibor) {
            JenisKeyboard.HURUF, JenisKeyboard.SIMBOL_ANGKA, JenisKeyboard.SIMBOL_TAMBAHAN -> {
                TampilanHurufDanSimbol(
                    jenisKibor = jenisKibor,
                    keadaanShift = keadaanShift,
                    tinggiKiborDp = tinggiKiborDp,
                    ukuranHurufSp = ukuranHurufSp,
                    apakahGetarAktif = apakahGetarAktif,
                    apakahSuaraAktif = apakahSuaraAktif,
                    getarHelper = getarHelper,
                    suaraHelper = suaraHelper,
                    onTekanTombol = { teks ->
                        onTekanTombol(teks)
                        if (keadaanShift == KeadaanShift.BESAR) {
                            keadaanShift = KeadaanShift.KECIL
                        }
                    },
                    onHapusSatuKarakter = onHapusSatuKarakter,
                    onGantiShift = {
                        keadaanShift = when (keadaanShift) {
                            KeadaanShift.KECIL -> KeadaanShift.BESAR
                            KeadaanShift.BESAR -> KeadaanShift.CAPSLOCK
                            KeadaanShift.CAPSLOCK -> KeadaanShift.KECIL
                        }
                    },
                    onGantiJenisKibor = { jenisKibor = it }
                )
            }
            JenisKeyboard.EMOJI -> {
                TampilanPanelEmoji(
                    tinggiKiborDp = tinggiKiborDp,
                    apakahGetarAktif = apakahGetarAktif,
                    apakahSuaraAktif = apakahSuaraAktif,
                    getarHelper = getarHelper,
                    suaraHelper = suaraHelper,
                    onTekanEmoji = onTekanTombol,
                    onKembaliKeHuruf = { jenisKibor = JenisKeyboard.HURUF }
                )
            }
            JenisKeyboard.CLIPBOARD -> {
                TampilanPanelClipboard(
                    tinggiKiborDp = tinggiKiborDp,
                    daftarClipboard = daftarClipboard,
                    apakahGetarAktif = apakahGetarAktif,
                    apakahSuaraAktif = apakahSuaraAktif,
                    getarHelper = getarHelper,
                    suaraHelper = suaraHelper,
                    onPilihClipboard = onTekanTombol,
                    onUbahPin = onUbahPin,
                    onUbahFavorit = onUbahFavorit,
                    onHapusClipboard = onHapusClipboard,
                    onKembaliKeHuruf = { jenisKibor = JenisKeyboard.HURUF }
                )
            }
        }
    }
}

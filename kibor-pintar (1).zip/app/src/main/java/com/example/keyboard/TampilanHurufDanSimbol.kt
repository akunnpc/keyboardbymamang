package com.example.keyboard

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.KeyboardBackspace
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material.icons.filled.KeyboardCapslock
import androidx.compose.material.icons.filled.SpaceBar
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.utilitas.AlatGetar
import com.example.utilitas.AlatSuara

@Composable
fun TampilanHurufDanSimbol(
    jenisKibor: JenisKeyboard,
    keadaanShift: KeadaanShift,
    tinggiKiborDp: Int,
    ukuranHurufSp: Float,
    apakahGetarAktif: Boolean,
    apakahSuaraAktif: Boolean,
    getarHelper: AlatGetar,
    suaraHelper: AlatSuara,
    onTekanTombol: (String) -> Unit,
    onHapusSatuKarakter: () -> Unit,
    onGantiShift: () -> Unit,
    onGantiJenisKibor: (JenisKeyboard) -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .height(tinggiKiborDp.dp)
            .background(Color(0xFF202124))
            .padding(horizontal = 4.dp, vertical = 6.dp),
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        if (jenisKibor == JenisKeyboard.HURUF) {
            TampilkanTataLetakHuruf(
                keadaanShift = keadaanShift,
                ukuranHurufSp = ukuranHurufSp,
                apakahGetarAktif = apakahGetarAktif,
                apakahSuaraAktif = apakahSuaraAktif,
                getarHelper = getarHelper,
                suaraHelper = suaraHelper,
                onTekanTombol = onTekanTombol,
                onHapusSatuKarakter = onHapusSatuKarakter,
                onGantiShift = onGantiShift,
                onGantiJenisKibor = onGantiJenisKibor
            )
        } else {
            TampilkanTataLetakSimbol(
                jenisKibor = jenisKibor,
                ukuranHurufSp = ukuranHurufSp,
                apakahGetarAktif = apakahGetarAktif,
                apakahSuaraAktif = apakahSuaraAktif,
                getarHelper = getarHelper,
                suaraHelper = suaraHelper,
                onTekanTombol = onTekanTombol,
                onHapusSatuKarakter = onHapusSatuKarakter,
                onGantiJenisKibor = onGantiJenisKibor
            )
        }
    }
}

@Composable
fun TampilkanTataLetakHuruf(
    keadaanShift: KeadaanShift,
    ukuranHurufSp: Float,
    apakahGetarAktif: Boolean,
    apakahSuaraAktif: Boolean,
    getarHelper: AlatGetar,
    suaraHelper: AlatSuara,
    onTekanTombol: (String) -> Unit,
    onHapusSatuKarakter: () -> Unit,
    onGantiShift: () -> Unit,
    onGantiJenisKibor: (JenisKeyboard) -> Unit
) {
    val barisSatu = listOf("q", "w", "e", "r", "t", "y", "u", "i", "o", "p")
    val barisDua = listOf("a", "s", "d", "f", "g", "h", "j", "k", "l")
    val barisTiga = listOf("z", "x", "c", "v", "b", "n", "m")

    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
        barisSatu.forEach { huruf ->
            val karakterAkhir = sesuaikanHuruf(huruf, keadaanShift)
            TombolKiborKustom(
                teks = karakterAkhir,
                modifier = Modifier.weight(1f),
                ukuranHurufSp = ukuranHurufSp,
                apakahGetarAktif = apakahGetarAktif,
                apakahSuaraAktif = apakahSuaraAktif,
                getarHelper = getarHelper,
                suaraHelper = suaraHelper,
                onClick = { onTekanTombol(karakterAkhir) }
            )
        }
    }

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 10.dp),
        horizontalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        barisDua.forEach { huruf ->
            val karakterAkhir = sesuaikanHuruf(huruf, keadaanShift)
            TombolKiborKustom(
                teks = karakterAkhir,
                modifier = Modifier.weight(1f),
                ukuranHurufSp = ukuranHurufSp,
                apakahGetarAktif = apakahGetarAktif,
                apakahSuaraAktif = apakahSuaraAktif,
                getarHelper = getarHelper,
                suaraHelper = suaraHelper,
                onClick = { onTekanTombol(karakterAkhir) }
            )
        }
    }

    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
        TombolAksiShift(
            keadaanShift = keadaanShift,
            modifier = Modifier.weight(1.5f),
            apakahGetarAktif = apakahGetarAktif,
            apakahSuaraAktif = apakahSuaraAktif,
            getarHelper = getarHelper,
            suaraHelper = suaraHelper,
            onClick = onGantiShift
        )

        barisTiga.forEach { huruf ->
            val karakterAkhir = sesuaikanHuruf(huruf, keadaanShift)
            TombolKiborKustom(
                teks = karakterAkhir,
                modifier = Modifier.weight(1f),
                ukuranHurufSp = ukuranHurufSp,
                apakahGetarAktif = apakahGetarAktif,
                apakahSuaraAktif = apakahSuaraAktif,
                getarHelper = getarHelper,
                suaraHelper = suaraHelper,
                onClick = { onTekanTombol(karakterAkhir) }
            )
        }

        TombolAksiBackspace(
            modifier = Modifier.weight(1.5f),
            apakahGetarAktif = apakahGetarAktif,
            apakahSuaraAktif = apakahSuaraAktif,
            getarHelper = getarHelper,
            suaraHelper = suaraHelper,
            onClick = onHapusSatuKarakter
        )
    }

    BarisTombolFungsiBawah(
        keadaanSimbol = false,
        ukuranHurufSp = ukuranHurufSp,
        apakahGetarAktif = apakahGetarAktif,
        apakahSuaraAktif = apakahSuaraAktif,
        getarHelper = getarHelper,
        suaraHelper = suaraHelper,
        onTekanTombol = onTekanTombol,
        onGantiJenisKibor = onGantiJenisKibor
    )
}

@Composable
fun TampilkanTataLetakSimbol(
    jenisKibor: JenisKeyboard,
    ukuranHurufSp: Float,
    apakahGetarAktif: Boolean,
    apakahSuaraAktif: Boolean,
    getarHelper: AlatGetar,
    suaraHelper: AlatSuara,
    onTekanTombol: (String) -> Unit,
    onHapusSatuKarakter: () -> Unit,
    onGantiJenisKibor: (JenisKeyboard) -> Unit
) {
    val barisSatu = if (jenisKibor == JenisKeyboard.SIMBOL_ANGKA) {
        listOf("1", "2", "3", "4", "5", "6", "7", "8", "9", "0")
    } else {
        listOf("~", "`", "|", "•", "√", "π", "÷", "×", "¶", "∆")
    }

    val barisDua = if (jenisKibor == JenisKeyboard.SIMBOL_ANGKA) {
        listOf("@", "#", "$", "%", "&", "*", "-", "+", "(", ")")
    } else {
        listOf("£", "¢", "€", "¥", "^", "°", "=", "_", "{", "}")
    }

    val barisTiga = if (jenisKibor == JenisKeyboard.SIMBOL_ANGKA) {
        listOf("!", "\"", "'", ":", ";", "?", ",")
    } else {
        listOf("\\", "<", ">", "[", "]", "!", "?")
    }

    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
        barisSatu.forEach { simbol ->
            TombolKiborKustom(
                teks = simbol,
                modifier = Modifier.weight(1f),
                ukuranHurufSp = ukuranHurufSp,
                apakahGetarAktif = apakahGetarAktif,
                apakahSuaraAktif = apakahSuaraAktif,
                getarHelper = getarHelper,
                suaraHelper = suaraHelper,
                onClick = { onTekanTombol(simbol) }
            )
        }
    }

    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
        barisDua.forEach { simbol ->
            TombolKiborKustom(
                teks = simbol,
                modifier = Modifier.weight(1f),
                ukuranHurufSp = ukuranHurufSp,
                apakahGetarAktif = apakahGetarAktif,
                apakahSuaraAktif = apakahSuaraAktif,
                getarHelper = getarHelper,
                suaraHelper = suaraHelper,
                onClick = { onTekanTombol(simbol) }
            )
        }
    }

    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
        TombolGantiSimbolTambahan(
            jenisKibor = jenisKibor,
            modifier = Modifier.weight(1.5f),
            apakahGetarAktif = apakahGetarAktif,
            apakahSuaraAktif = apakahSuaraAktif,
            getarHelper = getarHelper,
            suaraHelper = suaraHelper,
            onGantiJenisKibor = onGantiJenisKibor
        )

        barisTiga.forEach { simbol ->
            TombolKiborKustom(
                teks = simbol,
                modifier = Modifier.weight(1f),
                ukuranHurufSp = ukuranHurufSp,
                apakahGetarAktif = apakahGetarAktif,
                apakahSuaraAktif = apakahSuaraAktif,
                getarHelper = getarHelper,
                suaraHelper = suaraHelper,
                onClick = { onTekanTombol(simbol) }
            )
        }

        TombolAksiBackspace(
            modifier = Modifier.weight(1.5f),
            apakahGetarAktif = apakahGetarAktif,
            apakahSuaraAktif = apakahSuaraAktif,
            getarHelper = getarHelper,
            suaraHelper = suaraHelper,
            onClick = onHapusSatuKarakter
        )
    }

    BarisTombolFungsiBawah(
        keadaanSimbol = true,
        ukuranHurufSp = ukuranHurufSp,
        apakahGetarAktif = apakahGetarAktif,
        apakahSuaraAktif = apakahSuaraAktif,
        getarHelper = getarHelper,
        suaraHelper = suaraHelper,
        onTekanTombol = onTekanTombol,
        onGantiJenisKibor = onGantiJenisKibor
    )
}

@Composable
fun BarisTombolFungsiBawah(
    keadaanSimbol: Boolean,
    ukuranHurufSp: Float,
    apakahGetarAktif: Boolean,
    apakahSuaraAktif: Boolean,
    getarHelper: AlatGetar,
    suaraHelper: AlatSuara,
    onTekanTombol: (String) -> Unit,
    onGantiJenisKibor: (JenisKeyboard) -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        TombolKiborKustom(
            teks = if (keadaanSimbol) "ABC" else "?123",
            modifier = Modifier.weight(1.5f),
            warnaLatar = Color(0xFF3C4043),
            ukuranHurufSp = 14f,
            apakahGetarAktif = apakahGetarAktif,
            apakahSuaraAktif = apakahSuaraAktif,
            getarHelper = getarHelper,
            suaraHelper = suaraHelper,
            onClick = {
                if (keadaanSimbol) {
                    onGantiJenisKibor(JenisKeyboard.HURUF)
                } else {
                    onGantiJenisKibor(JenisKeyboard.SIMBOL_ANGKA)
                }
            }
        )

        TombolKiborKustom(
            teks = ",",
            modifier = Modifier.weight(1f),
            ukuranHurufSp = ukuranHurufSp,
            apakahGetarAktif = apakahGetarAktif,
            apakahSuaraAktif = apakahSuaraAktif,
            getarHelper = getarHelper,
            suaraHelper = suaraHelper,
            onClick = { onTekanTombol(",") }
        )

        Box(
            modifier = Modifier
                .weight(4f)
                .height(46.dp)
                .clip(RoundedCornerShape(8.dp))
                .background(Color(0xFF5F6368))
                .clickable {
                    if (apakahGetarAktif) getarHelper.getarkan(15)
                    if (apakahSuaraAktif) suaraHelper.bunyikan()
                    onTekanTombol(" ")
                },
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = Icons.Default.SpaceBar,
                contentDescription = "Spasi",
                tint = Color.White
            )
        }

        TombolKiborKustom(
            teks = ".",
            modifier = Modifier.weight(1f),
            ukuranHurufSp = ukuranHurufSp,
            apakahGetarAktif = apakahGetarAktif,
            apakahSuaraAktif = apakahSuaraAktif,
            getarHelper = getarHelper,
            suaraHelper = suaraHelper,
            onClick = { onTekanTombol(".") }
        )

        TombolKiborKustom(
            teks = "↵",
            modifier = Modifier.weight(1.5f),
            warnaLatar = Color(0xFF8AB4F8),
            warnaTeks = Color.Black,
            ukuranHurufSp = 20f,
            apakahGetarAktif = apakahGetarAktif,
            apakahSuaraAktif = apakahSuaraAktif,
            getarHelper = getarHelper,
            suaraHelper = suaraHelper,
            onClick = { onTekanTombol("\n") }
        )
    }
}

@Composable
fun TombolKiborKustom(
    teks: String,
    modifier: Modifier = Modifier,
    warnaLatar: Color = Color(0xFF303134),
    warnaTeks: Color = Color.White,
    ukuranHurufSp: Float = 16f,
    apakahGetarAktif: Boolean,
    apakahSuaraAktif: Boolean,
    getarHelper: AlatGetar,
    suaraHelper: AlatSuara,
    onClick: () -> Unit
) {
    val interaksi = remember { MutableInteractionSource() }
    Box(
        modifier = modifier
            .height(46.dp)
            .clip(RoundedCornerShape(8.dp))
            .background(warnaLatar)
            .clickable(
                interactionSource = interaksi,
                indication = null
            ) {
                if (apakahGetarAktif) getarHelper.getarkan(15)
                if (apakahSuaraAktif) suaraHelper.bunyikan()
                onClick()
            },
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = teks,
            color = warnaTeks,
            fontSize = ukuranHurufSp.sp
        )
    }
}

@Composable
fun TombolAksiShift(
    keadaanShift: KeadaanShift,
    modifier: Modifier = Modifier,
    apakahGetarAktif: Boolean,
    apakahSuaraAktif: Boolean,
    getarHelper: AlatGetar,
    suaraHelper: AlatSuara,
    onClick: () -> Unit
) {
    val ikonShift = when (keadaanShift) {
        KeadaanShift.KECIL -> Icons.Default.KeyboardArrowUp
        KeadaanShift.BESAR -> Icons.Default.KeyboardArrowUp
        KeadaanShift.CAPSLOCK -> Icons.Default.KeyboardCapslock
    }
    val warnaIkon = if (keadaanShift == KeadaanShift.KECIL) Color.White else Color(0xFF8AB4F8)
    val warnaLatar = if (keadaanShift == KeadaanShift.KECIL) Color(0xFF3C4043) else Color(0xFF424345)

    Box(
        modifier = modifier
            .height(46.dp)
            .clip(RoundedCornerShape(8.dp))
            .background(warnaLatar)
            .clickable {
                if (apakahGetarAktif) getarHelper.getarkan(15)
                if (apakahSuaraAktif) suaraHelper.bunyikan()
                onClick()
            },
        contentAlignment = Alignment.Center
    ) {
        Icon(
            imageVector = ikonShift,
            contentDescription = "Shift",
            tint = warnaIkon
        )
    }
}

@Composable
fun TombolAksiBackspace(
    modifier: Modifier = Modifier,
    apakahGetarAktif: Boolean,
    apakahSuaraAktif: Boolean,
    getarHelper: AlatGetar,
    suaraHelper: AlatSuara,
    onClick: () -> Unit
) {
    Box(
        modifier = modifier
            .height(46.dp)
            .clip(RoundedCornerShape(8.dp))
            .background(Color(0xFF3C4043))
            .clickable {
                if (apakahGetarAktif) getarHelper.getarkan(20)
                if (apakahSuaraAktif) suaraHelper.bunyikan()
                onClick()
            },
        contentAlignment = Alignment.Center
    ) {
        Icon(
            imageVector = Icons.AutoMirrored.Filled.KeyboardBackspace,
            contentDescription = "Backspace",
            tint = Color.White
        )
    }
}

@Composable
fun TombolGantiSimbolTambahan(
    jenisKibor: JenisKeyboard,
    modifier: Modifier = Modifier,
    apakahGetarAktif: Boolean,
    apakahSuaraAktif: Boolean,
    getarHelper: AlatGetar,
    suaraHelper: AlatSuara,
    onGantiJenisKibor: (JenisKeyboard) -> Unit
) {
    val teksTombol = if (jenisKibor == JenisKeyboard.SIMBOL_ANGKA) "=\\<" else "?123"
    val targetJenis = if (jenisKibor == JenisKeyboard.SIMBOL_ANGKA) {
        JenisKeyboard.SIMBOL_TAMBAHAN
    } else {
        JenisKeyboard.SIMBOL_ANGKA
    }

    Box(
        modifier = modifier
            .height(46.dp)
            .clip(RoundedCornerShape(8.dp))
            .background(Color(0xFF3C4043))
            .clickable {
                if (apakahGetarAktif) getarHelper.getarkan(15)
                if (apakahSuaraAktif) suaraHelper.bunyikan()
                onGantiJenisKibor(targetJenis)
            },
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = teksTombol,
            color = Color.White,
            fontSize = 14.sp
        )
    }
}

private fun sesuaikanHuruf(huruf: String, keadaanShift: KeadaanShift): String {
    return when (keadaanShift) {
        KeadaanShift.KECIL -> huruf.lowercase()
        KeadaanShift.BESAR, KeadaanShift.CAPSLOCK -> huruf.uppercase()
    }
}

package com.example.keyboard

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Keyboard
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.emoji.DaftarEmoji
import com.example.utilitas.AlatGetar
import com.example.utilitas.AlatSuara

@Composable
fun TampilanPanelEmoji(
    tinggiKiborDp: Int,
    apakahGetarAktif: Boolean,
    apakahSuaraAktif: Boolean,
    getarHelper: AlatGetar,
    suaraHelper: AlatSuara,
    onTekanEmoji: (String) -> Unit,
    onKembaliKeHuruf: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .height(tinggiKiborDp.dp)
            .background(Color(0xFF202124))
            .padding(horizontal = 4.dp, vertical = 6.dp)
    ) {
        LazyVerticalGrid(
            columns = GridCells.Adaptive(minSize = 48.dp),
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth(),
            contentPadding = PaddingValues(4.dp),
            horizontalArrangement = Arrangement.spacedBy(6.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            items(DaftarEmoji.DAFTAR_EMOJI_DASAR) { emoji ->
                Box(
                    modifier = Modifier
                        .size(48.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .clickable {
                            if (apakahGetarAktif) getarHelper.getarkan(10)
                            if (apakahSuaraAktif) suaraHelper.bunyikan()
                            onTekanEmoji(emoji)
                        },
                    contentAlignment = Alignment.Center
                ) {
                    Text(text = emoji, fontSize = 28.sp)
                }
            }
        }

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .height(48.dp)
                .padding(top = 4.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .weight(1f)
                    .height(40.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(Color(0xFF3C4043))
                    .clickable {
                        if (apakahGetarAktif) getarHelper.getarkan(15)
                        if (apakahSuaraAktif) suaraHelper.bunyikan()
                        onKembaliKeHuruf()
                    },
                contentAlignment = Alignment.Center
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Keyboard,
                        contentDescription = "Ganti Huruf",
                        tint = Color.White
                    )
                    Text(text = "ABC", color = Color.White, fontSize = 14.sp)
                }
            }
        }
    }
}

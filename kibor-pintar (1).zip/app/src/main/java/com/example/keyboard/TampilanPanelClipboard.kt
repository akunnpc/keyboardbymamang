package com.example.keyboard

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.database.EntitasClipboard
import com.example.utilitas.AlatGetar
import com.example.utilitas.AlatSuara

@Composable
fun TampilanPanelClipboard(
    tinggiKiborDp: Int,
    daftarClipboard: List<EntitasClipboard>,
    apakahGetarAktif: Boolean,
    apakahSuaraAktif: Boolean,
    getarHelper: AlatGetar,
    suaraHelper: AlatSuara,
    onPilihClipboard: (String) -> Unit,
    onUbahPin: (Int, Boolean) -> Unit,
    onUbahFavorit: (Int, Boolean) -> Unit,
    onHapusClipboard: (Int) -> Unit,
    onKembaliKeHuruf: () -> Unit
) {
    var kataKunciCari by remember { mutableStateOf("") }
    val daftarDisaring = remember(daftarClipboard, kataKunciCari) {
        if (kataKunciCari.isBlank()) {
            daftarClipboard
        } else {
            daftarClipboard.filter {
                it.teksClipboard.contains(kataKunciCari, ignoreCase = true) ||
                (it.labelTag?.contains(kataKunciCari, ignoreCase = true) == true)
            }
        }
    }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .height(tinggiKiborDp.dp)
            .background(Color(0xFF202124))
            .padding(horizontal = 4.dp, vertical = 6.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Box(
                modifier = Modifier
                    .weight(1f)
                    .height(38.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(Color(0xFF303134))
                    .padding(horizontal = 8.dp),
                contentAlignment = Alignment.CenterStart
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Search,
                        contentDescription = "Cari",
                        tint = Color.Gray,
                        modifier = Modifier.size(18.dp)
                    )
                    BasicTextField(
                        value = kataKunciCari,
                        onValueChange = { kataKunciCari = it },
                        textStyle = TextStyle(color = Color.White, fontSize = 14.sp),
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true,
                        decorationBox = { bagianDalam ->
                            if (kataKunciCari.isEmpty()) {
                                Text("Cari riwayat clipboard...", color = Color.Gray, fontSize = 14.sp)
                            }
                            bagianDalam()
                        }
                    )
                }
            }

            Box(
                modifier = Modifier
                    .size(38.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(Color(0xFF3C4043))
                    .clickable {
                        if (apakahGetarAktif) getarHelper.getarkan(15)
                        if (apakahSuaraAktif) suaraHelper.bunyikan()
                        onKembaliKeHuruf()
                    },
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.Keyboard,
                    contentDescription = "Kembali ke keyboard",
                    tint = Color.White,
                    modifier = Modifier.size(20.dp)
                )
            }
        }

        if (daftarDisaring.isEmpty()) {
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth(),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "Riwayat clipboard kosong",
                    color = Color.Gray,
                    fontSize = 14.sp
                )
            }
        } else {
            LazyColumn(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                items(daftarDisaring, key = { it.idClipboard }) { itemClipboard ->
                    BarisRiwayatClipboard(
                        itemClipboard = itemClipboard,
                        apakahGetarAktif = apakahGetarAktif,
                        apakahSuaraAktif = apakahSuaraAktif,
                        getarHelper = getarHelper,
                        suaraHelper = suaraHelper,
                        onPilih = { onPilihClipboard(itemClipboard.teksClipboard) },
                        onPinToggled = { onPinToggled(itemClipboard, onUbahPin) },
                        onFavoritToggled = { onFavoritToggled(itemClipboard, onUbahFavorit) },
                        onHapus = { onHapusClipboard(itemClipboard.idClipboard) }
                    )
                }
            }
        }
    }
}

private fun onPinToggled(itemClipboard: EntitasClipboard, onUbahPin: (Int, Boolean) -> Unit) {
    onUbahPin(itemClipboard.idClipboard, !itemClipboard.apakahDiPin)
}

private fun onFavoritToggled(itemClipboard: EntitasClipboard, onUbahFavorit: (Int, Boolean) -> Unit) {
    onUbahFavorit(itemClipboard.idClipboard, !itemClipboard.apakahFavorit)
}

@Composable
fun BarisRiwayatClipboard(
    itemClipboard: EntitasClipboard,
    apakahGetarAktif: Boolean,
    apakahSuaraAktif: Boolean,
    getarHelper: AlatGetar,
    suaraHelper: AlatSuara,
    onPilih: () -> Unit,
    onPinToggled: () -> Unit,
    onFavoritToggled: () -> Unit,
    onHapus: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(8.dp))
            .background(Color(0xFF2B2C2F))
            .clickable {
                if (apakahGetarAktif) getarHelper.getarkan(15)
                if (apakahSuaraAktif) suaraHelper.bunyikan()
                onPilih()
            }
            .padding(horizontal = 10.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Column(
            modifier = Modifier.weight(1f)
        ) {
            Text(
                text = itemClipboard.teksClipboard,
                color = Color.White,
                fontSize = 14.sp,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis
            )
            if (!itemClipboard.labelTag.isNullOrBlank() || !itemClipboard.namaFolder.isNullOrBlank()) {
                Row(
                    modifier = Modifier.padding(top = 2.dp),
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    if (!itemClipboard.namaFolder.isNullOrBlank()) {
                        Text(
                            text = "📁 ${itemClipboard.namaFolder}",
                            color = Color(0xFF8AB4F8),
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    if (!itemClipboard.labelTag.isNullOrBlank()) {
                        Text(
                            text = "🏷️ ${itemClipboard.labelTag}",
                            color = Color(0xFFFFB74D),
                            fontSize = 11.sp
                        )
                    }
                }
            }
        }

        Icon(
            imageVector = if (itemClipboard.apakahDiPin) Icons.Default.PushPin else Icons.Default.PinEnd,
            contentDescription = "Sematkan",
            tint = if (itemClipboard.apakahDiPin) Color(0xFF8AB4F8) else Color.Gray,
            modifier = Modifier
                .size(24.dp)
                .clickable {
                    if (apakahGetarAktif) getarHelper.getarkan(15)
                    onPinToggled()
                }
                .padding(2.dp)
        )

        Icon(
            imageVector = if (itemClipboard.apakahFavorit) Icons.Default.Star else Icons.Default.StarBorder,
            contentDescription = "Favorit",
            tint = if (itemClipboard.apakahFavorit) Color(0xFFFFD54F) else Color.Gray,
            modifier = Modifier
                .size(24.dp)
                .clickable {
                    if (apakahGetarAktif) getarHelper.getarkan(15)
                    onFavoritToggled()
                }
                .padding(2.dp)
        )

        Icon(
            imageVector = Icons.Default.Delete,
            contentDescription = "Hapus",
            tint = Color.LightGray,
            modifier = Modifier
                .size(24.dp)
                .clickable {
                    if (apakahGetarAktif) getarHelper.getarkan(15)
                    onHapus()
                }
                .padding(2.dp)
        )
    }
}

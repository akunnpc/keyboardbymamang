package com.example.pengaturan

import android.content.Context
import android.content.SharedPreferences

class PenyimpananPengaturan(konteks: Context) {
    private val preferensi: SharedPreferences = konteks.getSharedPreferences(
        "preferensi_kibor_pintar",
        Context.MODE_PRIVATE
    )

    companion object {
        private const val KUNCI_GETAR = "getar_tombol"
        private const val KUNCI_SUARA = "suara_tombol"
        private const val KUNCI_TINGGI = "tinggi_keyboard"
        private const val KUNCI_UKURAN_HURUF = "ukuran_huruf_tombol"
        private const val KUNCI_AUTO_KAPITAL = "auto_kapital"
        private const val KUNCI_POPUP_HURUF = "tampilkan_popup_huruf"
        private const val KUNCI_NAMA_TEMA = "nama_tema"
        private const val KUNCI_WARNA_TEMA = "warna_tema_utama"
        private const val KUNCI_BAHASA = "bahasa_keyboard"
    }

    var apakahGetarAktif: Boolean
        get() = preferensi.getBoolean(KUNCI_GETAR, true)
        set(nilai) = preferensi.edit().putBoolean(KUNCI_GETAR, nilai).apply()

    var apakahSuaraAktif: Boolean
        get() = preferensi.getBoolean(KUNCI_SUARA, false)
        set(nilai) = preferensi.edit().putBoolean(KUNCI_SUARA, nilai).apply()

    var tinggiKeyboardDlmDp: Int
        get() = preferensi.getInt(KUNCI_TINGGI, 260)
        set(nilai) = preferensi.edit().putInt(KUNCI_TINGGI, nilai).apply()

    var ukuranHurufTombolSp: Float
        get() = preferensi.getFloat(KUNCI_UKURAN_HURUF, 16f)
        set(nilai) = preferensi.edit().putFloat(KUNCI_UKURAN_HURUF, nilai).apply()

    var apakahAutoKapitalAktif: Boolean
        get() = preferensi.getBoolean(KUNCI_AUTO_KAPITAL, true)
        set(nilai) = preferensi.edit().putBoolean(KUNCI_AUTO_KAPITAL, nilai).apply()

    var apakahPopupHurufAktif: Boolean
        get() = preferensi.getBoolean(KUNCI_POPUP_HURUF, true)
        set(nilai) = preferensi.edit().putBoolean(KUNCI_POPUP_HURUF, nilai).apply()

    var namaTemaAktif: String
        get() = preferensi.getString(KUNCI_NAMA_TEMA, "BawaanGelap") ?: "BawaanGelap"
        set(nilai) = preferensi.edit().putString(KUNCI_NAMA_TEMA, nilai).apply()

    var warnaTemaUtamaHex: Int
        get() = preferensi.getInt(KUNCI_WARNA_TEMA, 0xFF202124.toInt())
        set(nilai) = preferensi.edit().putInt(KUNCI_WARNA_TEMA, nilai).apply()

    var bahasaKibor: String
        get() = preferensi.getString(KUNCI_BAHASA, "Indonesia") ?: "Indonesia"
        set(nilai) = preferensi.edit().putString(KUNCI_BAHASA, nilai).apply()
}

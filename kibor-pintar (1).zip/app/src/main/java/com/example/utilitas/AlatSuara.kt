package com.example.utilitas

import android.content.Context
import android.media.AudioManager

class AlatSuara(konteks: Context) {
    private val pengelolaSuara = konteks.getSystemService(Context.AUDIO_SERVICE) as? AudioManager

    fun bunyikan() {
        try {
            pengelolaSuara?.playSoundEffect(AudioManager.FX_KEYPRESS_STANDARD)
        } catch (kesalahan: Exception) {
            // Abaikan jika terjadi galat dalam pemutaran suara
        }
    }
}

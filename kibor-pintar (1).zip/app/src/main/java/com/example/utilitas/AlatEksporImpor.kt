package com.example.utilitas

import android.content.Context
import com.example.database.EntitasClipboard
import com.squareup.moshi.Moshi
import com.squareup.moshi.Types
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory

class AlatEksporImpor(private val konteks: Context) {
    private val moshi = Moshi.Builder().addLast(KotlinJsonAdapterFactory()).build()
    private val tipeDaftar = Types.newParameterizedType(List::class.java, EntitasClipboard::class.java)
    private val adapterJson = moshi.adapter<List<EntitasClipboard>>(tipeDaftar)

    fun eksporKeJson(daftarClipboard: List<EntitasClipboard>): String? {
        return try {
            adapterJson.toJson(daftarClipboard)
        } catch (galat: Exception) {
            null
        }
    }

    fun imporDariJson(teksJson: String): List<EntitasClipboard>? {
        return try {
            adapterJson.fromJson(teksJson)
        } catch (galat: Exception) {
            null
        }
    }
}

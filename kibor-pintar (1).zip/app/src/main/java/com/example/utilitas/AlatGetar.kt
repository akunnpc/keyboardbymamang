package com.example.utilitas

import android.content.Context
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager

class AlatGetar(konteks: Context) {
    private val penggetar: Vibrator? = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
        val pengelolaGetar = konteks.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager
        pengelolaGetar?.defaultVibrator
    } else {
        @Suppress("DEPRECATION")
        konteks.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
    }

    fun getarkan(durasiMilidetik: Long = 15) {
        if (penggetar == null || !penggetar.hasVibrator()) return
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                penggetar.vibrate(
                    VibrationEffect.createOneShot(
                        durasiMilidetik,
                        VibrationEffect.DEFAULT_AMPLITUDE
                    )
                )
            } else {
                @Suppress("DEPRECATION")
                penggetar.vibrate(durasiMilidetik)
            }
        } catch (kesalahan: Exception) {
            // Abaikan jika terjadi galat dalam getaran
        }
    }
}

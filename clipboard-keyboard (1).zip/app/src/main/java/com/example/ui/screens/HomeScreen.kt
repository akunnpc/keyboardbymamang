package com.example.ui.screens

import android.content.Context
import android.content.Intent
import android.os.Build
import android.provider.Settings
import android.view.inputmethod.InputMethodManager
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ContentPaste
import androidx.compose.material.icons.filled.Keyboard
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.theme.KeyboardTheme
import com.example.viewmodel.ClipboardViewModel
import com.example.viewmodel.SettingsViewModel
import com.example.viewmodel.ThemeViewModel
import kotlinx.coroutines.delay

@Composable
fun HomeScreen(
    clipboardViewModel: ClipboardViewModel,
    settingsViewModel: SettingsViewModel,
    themeViewModel: ThemeViewModel,
    onNavigateToSettings: () -> Unit,
    onNavigateToHistory: () -> Unit
) {
    val context = LocalContext.current
    var isEnabled by remember { mutableStateOf(false) }
    var isDefault by remember { mutableStateOf(false) }

    // Periodically update keyboard active statuses
    LaunchedEffect(Unit) {
        while (true) {
            val imm = context.getSystemService(Context.INPUT_METHOD_SERVICE) as? InputMethodManager
            
            // Check if enabled using standard API
            val enabledList = imm?.enabledInputMethodList ?: emptyList()
            isEnabled = enabledList.any { it.packageName == context.packageName }

            // Check if default using Build-specific APIs
            isDefault = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
                try {
                    imm?.currentInputMethodInfo?.packageName == context.packageName
                } catch (e: Exception) {
                    false
                }
            } else {
                try {
                    val defaultMethod = Settings.Secure.getString(
                        context.contentResolver,
                        Settings.Secure.DEFAULT_INPUT_METHOD
                    ) ?: ""
                    defaultMethod.contains(context.packageName)
                } catch (e: Exception) {
                    false
                }
            }

            delay(1500)
        }
    }

    // Dynamic data subscriptions for the Bento Grid
    val clipboardEntries by clipboardViewModel.clipboardEntries.collectAsState()
    val allThemes by themeViewModel.allThemes.collectAsState()
    val selectedThemeId by settingsViewModel.selectedThemeId.collectAsState()

    val totalClips = clipboardEntries.size
    val latestEntry = clipboardEntries.firstOrNull()

    val activeTheme = allThemes.find { it.id == selectedThemeId } ?: KeyboardTheme.DARK_MINIMAL

    // Bento theme colors
    val bentoPageBg = Color(0xFFFEF7FF)
    val bentoTextPrimary = Color(0xFF1D1B20)

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(bentoPageBg)
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Top Header
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 4.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(40.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(Color(0xFF6750A4)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Keyboard,
                        contentDescription = "App Icon",
                        tint = Color.White,
                        modifier = Modifier.size(24.dp)
                    )
                }
                Column {
                    Text(
                        text = "Keyboard Studio",
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Bold,
                        color = bentoTextPrimary,
                        letterSpacing = (-0.5).sp
                    )
                }
            }

            Box(
                modifier = Modifier
                    .size(40.dp)
                    .clip(CircleShape)
                    .background(Color(0xFFF3EDF7))
                    .clickable { onNavigateToSettings() },
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.Settings,
                    contentDescription = "Pengaturan",
                    tint = bentoTextPrimary,
                    modifier = Modifier.size(20.dp)
                )
            }
        }

        // 1. Service Status Card (col-span-6 row-span-2)
        val statusBg = if (isEnabled && isDefault) Color(0xFFE8DEF8) else Color(0xFFFCE8E6)
        val statusTextCol = if (isEnabled && isDefault) Color(0xFF21005D) else Color(0xFF601410)
        val statusTitle = if (isEnabled && isDefault) "Keyboard is Active" else "Keyboard is Offline"
        val statusSub = if (isEnabled && isDefault) "Siap digunakan untuk mengetik!" else "Ketuk untuk mengaktifkan sekarang"

        Card(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(24.dp))
                .clickable {
                    if (!isEnabled) {
                        val intent = Intent(Settings.ACTION_INPUT_METHOD_SETTINGS)
                        context.startActivity(intent)
                    } else if (!isDefault) {
                        val im = context.getSystemService(Context.INPUT_METHOD_SERVICE) as? InputMethodManager
                        im?.showInputMethodPicker()
                    }
                },
            colors = CardDefaults.cardColors(containerColor = statusBg)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(18.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "Service Status",
                        color = statusTextCol.copy(alpha = 0.7f),
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Medium
                    )
                    Text(
                        text = statusTitle,
                        color = statusTextCol,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(top = 2.dp)
                    )
                    Text(
                        text = statusSub,
                        color = statusTextCol.copy(alpha = 0.8f),
                        fontSize = 12.sp,
                        modifier = Modifier.padding(top = 4.dp)
                    )
                }

                // Beautiful Custom Switch visualization
                Box(
                    modifier = Modifier
                        .size(width = 52.dp, height = 30.dp)
                        .clip(CircleShape)
                        .background(if (isEnabled && isDefault) Color(0xFF6750A4) else Color(0xFFCAC4D0).copy(alpha = 0.4f))
                        .padding(3.dp),
                    contentAlignment = if (isEnabled && isDefault) Alignment.CenterEnd else Alignment.CenterStart
                ) {
                    Box(
                        modifier = Modifier
                            .size(24.dp)
                            .clip(CircleShape)
                            .background(Color.White),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = if (isEnabled && isDefault) Icons.Default.Check else Icons.Default.Warning,
                            contentDescription = null,
                            tint = if (isEnabled && isDefault) Color(0xFF6750A4) else Color.Gray,
                            modifier = Modifier.size(14.dp)
                        )
                    }
                }
            }
        }

        // 2. Middle Row: Latest Copy & Total Stats Cards
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // Main Recent Clip Card (col-span-4)
            Card(
                modifier = Modifier
                    .weight(1.7f)
                    .height(170.dp)
                    .clip(RoundedCornerShape(24.dp))
                    .clickable { onNavigateToHistory() },
                colors = CardDefaults.cardColors(containerColor = Color(0xFFF3EDF7)),
                border = BorderStroke(1.dp, Color(0xFFE7E0EC))
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(14.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        modifier = Modifier.padding(bottom = 8.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.ContentPaste,
                            contentDescription = null,
                            tint = Color(0xFF49454F),
                            modifier = Modifier.size(16.dp)
                        )
                        Text(
                            text = "LATEST COPY",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF49454F),
                            letterSpacing = 1.sp
                        )
                    }

                    Text(
                        text = latestEntry?.fullText ?: "Belum ada teks yang disalin. Salin apa saja untuk mencoba!",
                        fontSize = 13.sp,
                        color = if (latestEntry != null) Color(0xFF49454F) else Color(0xFF79747E),
                        fontWeight = if (latestEntry != null) FontWeight.Medium else FontWeight.Normal,
                        maxLines = 4,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f)
                    )

                    Spacer(modifier = Modifier.height(6.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = if (latestEntry != null) "Baru saja disalin" else "Mulai menyalin",
                            fontSize = 10.sp,
                            color = Color(0xFF79747E)
                        )
                        Box(
                            modifier = Modifier
                                .size(8.dp)
                                .clip(CircleShape)
                                .background(if (latestEntry != null) Color(0xFF4CAF50) else Color.LightGray)
                        )
                    }
                }
            }

            // Stats Card (col-span-2)
            Card(
                modifier = Modifier
                    .weight(1f)
                    .height(170.dp)
                    .clip(RoundedCornerShape(24.dp))
                    .clickable { onNavigateToHistory() },
                colors = CardDefaults.cardColors(containerColor = Color(0xFFFFD8E4))
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(14.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Text(
                        text = if (totalClips >= 1000) String.format("%.1fk", totalClips / 1000.0) else totalClips.toString(),
                        fontSize = 42.sp,
                        fontWeight = FontWeight.Black,
                        color = Color(0xFF31111D),
                        textAlign = TextAlign.Center
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "TOTAL CLIPS",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF31111D),
                        textAlign = TextAlign.Center,
                        letterSpacing = 1.sp,
                        lineHeight = 12.sp
                    )
                }
            }
        }

        // 3. Bottom Row: Active Theme & Quick Setup Cards
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // Theme Preview Card (col-span-3)
            val themeBgParsed = try { Color(android.graphics.Color.parseColor(activeTheme.backgroundColor)) } catch (e: Exception) { Color(0xFF1A1A1A) }
            val themeAccentParsed = try { Color(android.graphics.Color.parseColor(activeTheme.accentColor)) } catch (e: Exception) { Color(0xFF4FC3F7) }
            val themeKeyBgParsed = try { Color(android.graphics.Color.parseColor(activeTheme.keyBackgroundColor)) } catch (e: Exception) { Color(0xFF37474F) }

            Card(
                modifier = Modifier
                    .weight(1f)
                    .height(180.dp)
                    .clip(RoundedCornerShape(24.dp))
                    .clickable { onNavigateToSettings() },
                colors = CardDefaults.cardColors(containerColor = themeBgParsed),
                border = BorderStroke(2.dp, themeAccentParsed)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(14.dp),
                    verticalArrangement = Arrangement.SpaceBetween
                ) {
                    // Miniature Color Palette Dots
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Box(modifier = Modifier.size(20.dp).clip(RoundedCornerShape(4.dp)).background(themeAccentParsed))
                        Box(modifier = Modifier.size(20.dp).clip(RoundedCornerShape(4.dp)).background(themeKeyBgParsed))
                        Box(modifier = Modifier.size(20.dp).clip(RoundedCornerShape(4.dp)).background(themeKeyBgParsed.copy(alpha = 0.7f)))
                        Box(modifier = Modifier.size(20.dp).clip(RoundedCornerShape(4.dp)).background(themeBgParsed.copy(alpha = 0.5f)).border(1.dp, Color.White.copy(alpha = 0.3f), RoundedCornerShape(4.dp)))
                    }

                    Column {
                        Text(
                            text = "ACTIVE THEME",
                            color = Color.White.copy(alpha = 0.6f),
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.sp
                        )
                        Text(
                            text = activeTheme.name.uppercase(),
                            color = themeAccentParsed,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }
            }

            // Quick Setup Card (col-span-3)
            Card(
                modifier = Modifier
                    .weight(1f)
                    .height(180.dp)
                    .clip(RoundedCornerShape(24.dp)),
                colors = CardDefaults.cardColors(containerColor = Color(0xFFD3E3FD))
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(14.dp),
                    verticalArrangement = Arrangement.SpaceBetween
                ) {
                    Column {
                        Text(
                            text = "How to Setup",
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp,
                            color = Color(0xFF041E49)
                        )
                        Text(
                            text = "Buka Settings > Virtual Keyboard > Aktifkan & pilih Clipboard Keyboard.",
                            fontSize = 10.sp,
                            lineHeight = 13.sp,
                            color = Color(0xFF041E49).copy(alpha = 0.8f),
                            modifier = Modifier.padding(top = 4.dp)
                        )
                    }

                    Button(
                        onClick = {
                            val intent = Intent(Settings.ACTION_INPUT_METHOD_SETTINGS)
                            context.startActivity(intent)
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(36.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0B57D0)),
                        shape = RoundedCornerShape(12.dp),
                        contentPadding = PaddingValues(0.dp)
                    ) {
                        Text(
                            text = "Open Settings",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                    }
                }
            }
        }

        // 4. Quick Action Footer Links
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(20.dp)),
            colors = CardDefaults.cardColors(containerColor = Color(0xFFF3EDF7)),
            border = BorderStroke(1.dp, Color(0xFFE7E0EC))
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(14.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "Kelola Keyboard Studio",
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp,
                        color = bentoTextPrimary
                    )
                    Text(
                        text = "Ekspor data, hapus history, atau buat tema custom.",
                        fontSize = 11.sp,
                        color = Color(0xFF49454F)
                    )
                }

                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .clip(CircleShape)
                        .background(Color(0xFF6750A4).copy(alpha = 0.1f))
                        .clickable { onNavigateToHistory() },
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.ArrowForward,
                        contentDescription = "Selengkapnya",
                        tint = Color(0xFF6750A4),
                        modifier = Modifier.size(18.dp)
                    )
                }
            }
        }
    }
}

// Add empty PaddingValues if missing to avoid import issue
@Composable
private fun PaddingValues(all: androidx.compose.ui.unit.Dp) = androidx.compose.foundation.layout.PaddingValues(all)

@Composable
private fun PaddingValues(horizontal: androidx.compose.ui.unit.Dp, vertical: androidx.compose.ui.unit.Dp) = 
    androidx.compose.foundation.layout.PaddingValues(horizontal, vertical)

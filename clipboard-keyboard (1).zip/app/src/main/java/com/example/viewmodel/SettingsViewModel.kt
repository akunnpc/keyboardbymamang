package com.example.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.example.util.SettingsManager
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

class SettingsViewModel(private val settingsManager: SettingsManager) : ViewModel() {

    private val _isClipboardEnabled = MutableStateFlow(settingsManager.isClipboardEnabled)
    val isClipboardEnabled: StateFlow<Boolean> = _isClipboardEnabled

    private val _autoDeleteDays = MutableStateFlow(settingsManager.autoDeleteDays)
    val autoDeleteDays: StateFlow<Int> = _autoDeleteDays

    private val _selectedThemeId = MutableStateFlow(settingsManager.selectedThemeId)
    val selectedThemeId: StateFlow<String> = _selectedThemeId

    private val _keyboardHeight = MutableStateFlow(settingsManager.keyboardHeight)
    val keyboardHeight: StateFlow<Int> = _keyboardHeight

    fun setClipboardEnabled(enabled: Boolean) {
        settingsManager.isClipboardEnabled = enabled
        _isClipboardEnabled.value = enabled
    }

    fun setAutoDeleteDays(days: Int) {
        settingsManager.autoDeleteDays = days
        _autoDeleteDays.value = days
    }

    fun setSelectedThemeId(themeId: String) {
        settingsManager.selectedThemeId = themeId
        _selectedThemeId.value = themeId
    }

    fun setKeyboardHeight(height: Int) {
        settingsManager.keyboardHeight = height
        _keyboardHeight.value = height
    }

    class Factory(private val settingsManager: SettingsManager) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            if (modelClass.isAssignableFrom(SettingsViewModel::class.java)) {
                return SettingsViewModel(settingsManager) as T
            }
            throw IllegalArgumentException("Unknown ViewModel class")
        }
    }
}

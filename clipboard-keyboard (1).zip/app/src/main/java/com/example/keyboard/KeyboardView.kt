package com.example.keyboard

import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.RippleDrawable
import android.content.res.ColorStateList
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.MotionEvent
import android.view.HapticFeedbackConstants
import android.widget.LinearLayout
import android.widget.TextView
import com.example.data.theme.KeyboardTheme
import com.example.util.SettingsManager

class KeyboardView(
    context: Context,
    private val theme: KeyboardTheme,
    private val listener: KeyboardActionListener
) : LinearLayout(context) {

    interface KeyboardActionListener {
        fun onKeyText(text: String)
        fun onBackspace()
        fun onShiftToggle()
        fun onEnter()
        fun onSpace()
    }

    private var currentMode = KeyboardMode.ABC
    private var isShifted = false

    private val keyboardContainer: LinearLayout

    enum class KeyboardMode {
        ABC, SYMBOLS, EMOJIS
    }

    init {
        orientation = VERTICAL
        layoutParams = LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT)
        setBackgroundColor(Color.parseColor(theme.backgroundColor))
        setPadding(0, dpToPx(6), 0, dpToPx(6))

        keyboardContainer = LinearLayout(context).apply {
            orientation = VERTICAL
            layoutParams = LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT)
        }
        addView(keyboardContainer)

        buildKeyboard()
    }

    private fun buildKeyboard() {
        keyboardContainer.removeAllViews()

        val rows = when (currentMode) {
            KeyboardMode.ABC -> if (isShifted) KeyboardLayout.qwertyRowsShifted else KeyboardLayout.qwertyRows
            KeyboardMode.SYMBOLS -> KeyboardLayout.symbolRows
            KeyboardMode.EMOJIS -> KeyboardLayout.emojiRows
        }

        for (row in rows) {
            val rowLayout = LinearLayout(context).apply {
                orientation = HORIZONTAL
                gravity = Gravity.CENTER
                layoutParams = LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT)
            }

            for (key in row) {
                val keyView = createKeyView(key)
                rowLayout.addView(keyView)
            }

            keyboardContainer.addView(rowLayout)
        }
    }

    private fun createKeyView(key: String): View {
        val button = TextView(context).apply {
            gravity = Gravity.CENTER
            textSize = 18f
            typeface = Typeface.DEFAULT_BOLD
            setPadding(0, dpToPx(12), 0, dpToPx(12))
        }

        // Apply theme colors & ripple
        val normalColor = Color.parseColor(theme.keyBackgroundColor)
        val pressedColor = Color.parseColor(theme.keyTextColor).adjustAlpha(0.2f)
        val accentColor = Color.parseColor(theme.accentColor)

        val baseDrawable = GradientDrawable().apply {
            cornerRadius = dpToPx(6).toFloat()
            setColor(normalColor)
        }

        val keyBg = RippleDrawable(
            ColorStateList.valueOf(pressedColor),
            baseDrawable,
            null
        )

        button.background = keyBg
        button.setTextColor(Color.parseColor(theme.keyTextColor))

        var weight = 1f
        var displayText = key

        when (key) {
            "[SHIFT]" -> {
                displayText = "⇧"
                weight = 1.4f
            }
            "[SHIFT_ACTIVE]" -> {
                displayText = "⇪"
                weight = 1.4f
                val activeBg = GradientDrawable().apply {
                    cornerRadius = dpToPx(6).toFloat()
                    setColor(accentColor)
                }
                button.background = RippleDrawable(ColorStateList.valueOf(pressedColor), activeBg, null)
                button.setTextColor(Color.parseColor(theme.backgroundColor))
            }
            "[BACKSPACE]" -> {
                displayText = "⌫"
                weight = 1.4f
            }
            "[SWITCH_123]" -> {
                displayText = "?123"
                weight = 1.5f
            }
            "[SWITCH_ABC]" -> {
                displayText = "abc"
                weight = 1.5f
            }
            "[SWITCH_EMOJI]" -> {
                displayText = "☺"
                weight = 1.2f
            }
            "[SPACE]" -> {
                displayText = "spasi"
                weight = 4.0f
            }
            "[ENTER]" -> {
                displayText = "↵"
                weight = 1.5f
                val enterBg = GradientDrawable().apply {
                    cornerRadius = dpToPx(6).toFloat()
                    setColor(accentColor)
                }
                button.background = RippleDrawable(ColorStateList.valueOf(pressedColor), enterBg, null)
                button.setTextColor(Color.parseColor(theme.backgroundColor))
            }
            "[CLIPBOARD]" -> {
                displayText = "📋"
                weight = 1.2f
            }
        }

        button.text = displayText

        // Load custom keyboard height from settings
        val keyboardHeightDp = SettingsManager(context).keyboardHeight
        // Scale text size slightly based on keyboard height
        button.textSize = 18f * (keyboardHeightDp.toFloat() / 48f)

        val lp = LayoutParams(0, dpToPx(keyboardHeightDp)).apply {
            this.weight = weight
            topMargin = dpToPx(4)
            bottomMargin = dpToPx(4)
            leftMargin = dpToPx(4)
            rightMargin = dpToPx(4)
        }
        button.layoutParams = lp

        // High responsiveness: trigger action instantly on MotionEvent.ACTION_DOWN!
        button.setOnTouchListener { v, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    v.isPressed = true
                    v.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
                    v.playSoundEffect(android.view.SoundEffectConstants.CLICK)
                    
                    // Trigger key action immediately
                    when (key) {
                        "[SHIFT]" -> {
                            isShifted = !isShifted
                            buildKeyboard()
                            listener.onShiftToggle()
                        }
                        "[SHIFT_ACTIVE]" -> {
                            isShifted = false
                            buildKeyboard()
                            listener.onShiftToggle()
                        }
                        "[BACKSPACE]" -> {
                            listener.onBackspace()
                        }
                        "[SWITCH_123]" -> {
                            currentMode = KeyboardMode.SYMBOLS
                            buildKeyboard()
                        }
                        "[SWITCH_ABC]" -> {
                            currentMode = KeyboardMode.ABC
                            buildKeyboard()
                        }
                        "[SWITCH_EMOJI]" -> {
                            currentMode = KeyboardMode.EMOJIS
                            buildKeyboard()
                        }
                        "[SPACE]" -> {
                            listener.onSpace()
                        }
                        "[ENTER]" -> {
                            listener.onEnter()
                        }
                        "[CLIPBOARD]" -> {
                            showClipboardPanel()
                        }
                        else -> {
                            listener.onKeyText(key)
                        }
                    }
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    v.isPressed = false
                }
            }
            true
        }

        return button
    }

    private fun showClipboardPanel() {
        keyboardContainer.visibility = View.GONE
        
        val clipboardPanel = ClipboardPanelView(
            context = context,
            theme = theme,
            onPaste = { text ->
                listener.onKeyText(text)
            },
            onClose = {
                // Remove panel and restore main keyboard keys
                val lastChild = getChildAt(childCount - 1)
                if (lastChild is ClipboardPanelView) {
                    removeView(lastChild)
                }
                keyboardContainer.visibility = View.VISIBLE
            }
        )
        
        addView(clipboardPanel)
    }

    private fun dpToPx(dp: Int): Int {
        return TypedValue.applyDimension(
            TypedValue.COMPLEX_UNIT_DIP,
            dp.toFloat(),
            context.resources.displayMetrics
        ).toInt()
    }

    private fun Int.adjustAlpha(factor: Float): Int {
        val alpha = Math.round(Color.alpha(this) * factor)
        val red = Color.red(this)
        val green = Color.green(this)
        val blue = Color.blue(this)
        return Color.argb(alpha, red, green, blue)
    }
}

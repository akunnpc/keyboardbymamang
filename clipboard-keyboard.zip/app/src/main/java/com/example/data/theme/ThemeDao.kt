package com.example.data.theme

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface ThemeDao {
    @Query("SELECT * FROM keyboard_themes ORDER BY isCustom DESC, name ASC")
    fun getAllThemes(): Flow<List<KeyboardTheme>>

    @Query("SELECT * FROM keyboard_themes WHERE isCustom = 1 ORDER BY name ASC")
    fun getCustomThemes(): Flow<List<KeyboardTheme>>

    @Query("SELECT * FROM keyboard_themes WHERE id = :id LIMIT 1")
    suspend fun getThemeById(id: String): KeyboardTheme?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTheme(theme: KeyboardTheme)

    @Delete
    suspend fun deleteTheme(theme: KeyboardTheme)

    @Query("DELETE FROM keyboard_themes WHERE id = :id")
    suspend fun deleteById(id: String)
}

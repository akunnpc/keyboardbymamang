package com.example.data.clipboard

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "clipboard_entries")
data class ClipboardEntry(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val fullText: String,
    val previewText: String,
    val timestamp: Long = System.currentTimeMillis(),
    val isPinned: Boolean = false
) {
    companion object {
        fun create(text: String, isPinned: Boolean = false): ClipboardEntry {
            // Generate the preview: first 2 lines
            val lines = text.trim().split("\n")
            val preview = if (lines.size > 2) {
                "${lines[0]}\n${lines[1]}..."
            } else if (text.length > 80) {
                text.take(80) + "..."
            } else {
                text
            }
            return ClipboardEntry(
                fullText = text,
                previewText = preview,
                timestamp = System.currentTimeMillis(),
                isPinned = isPinned
            )
        }
    }
}

package com.example.data.clipboard

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface ClipboardDao {
    @Query("SELECT * FROM clipboard_entries ORDER BY isPinned DESC, timestamp DESC")
    fun getAllEntries(): Flow<List<ClipboardEntry>>

    @Query("SELECT * FROM clipboard_entries WHERE fullText LIKE :query ORDER BY isPinned DESC, timestamp DESC")
    fun searchEntries(query: String): Flow<List<ClipboardEntry>>

    @Query("SELECT * FROM clipboard_entries WHERE fullText = :text LIMIT 1")
    suspend fun getEntryByText(text: String): ClipboardEntry?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertEntry(entry: ClipboardEntry)

    @Delete
    suspend fun deleteEntry(entry: ClipboardEntry)

    @Query("DELETE FROM clipboard_entries WHERE id = :id")
    suspend fun deleteById(id: Int)

    @Query("DELETE FROM clipboard_entries WHERE isPinned = 0")
    suspend fun deleteAllUnpinned()

    @Query("DELETE FROM clipboard_entries")
    suspend fun deleteAll()

    @Query("DELETE FROM clipboard_entries WHERE isPinned = 0 AND timestamp < :threshold")
    suspend fun deleteOlderThan(threshold: Long)
}

package com.example.data.clipboard

import kotlinx.coroutines.flow.Flow

class ClipboardRepository(private val clipboardDao: ClipboardDao) {
    val allEntries: Flow<List<ClipboardEntry>> = clipboardDao.getAllEntries()

    fun searchEntries(query: String): Flow<List<ClipboardEntry>> {
        return clipboardDao.searchEntries("%$query%")
    }

    suspend fun insertText(text: String) {
        if (text.isBlank()) return
        val existing = clipboardDao.getEntryByText(text)
        if (existing != null) {
            // Update timestamp to put it on top, keeping its pinned status
            clipboardDao.insertEntry(
                existing.copy(timestamp = System.currentTimeMillis())
            )
        } else {
            clipboardDao.insertEntry(ClipboardEntry.create(text))
        }
    }

    suspend fun insert(entry: ClipboardEntry) {
        clipboardDao.insertEntry(entry)
    }

    suspend fun togglePin(entry: ClipboardEntry) {
        clipboardDao.insertEntry(entry.copy(isPinned = !entry.isPinned))
    }

    suspend fun delete(entry: ClipboardEntry) {
        clipboardDao.deleteEntry(entry)
    }

    suspend fun deleteById(id: Int) {
        clipboardDao.deleteById(id)
    }

    suspend fun clearAllUnpinned() {
        clipboardDao.deleteAllUnpinned()
    }

    suspend fun deleteOlderThanDays(days: Int) {
        if (days <= 0) return
        val threshold = System.currentTimeMillis() - (days.toLong() * 24 * 60 * 60 * 1000)
        clipboardDao.deleteOlderThan(threshold)
    }
}

package com.example.data.theme

import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

class ThemeRepository(private val themeDao: ThemeDao) {
    val allThemes: Flow<List<KeyboardTheme>> = themeDao.getAllThemes().map { dbThemes ->
        // Ensure that presets are always present in the returned list
        val presets = KeyboardTheme.PRESETS
        val presetIds = presets.map { it.id }.toSet()
        val customAndOverridden = dbThemes.filter { it.isCustom || !presetIds.contains(it.id) }
        presets + customAndOverridden
    }

    suspend fun getThemeById(id: String): KeyboardTheme? {
        val preset = KeyboardTheme.PRESETS.firstOrNull { it.id == id }
        if (preset != null) return preset
        return themeDao.getThemeById(id)
    }

    suspend fun saveTheme(theme: KeyboardTheme) {
        themeDao.insertTheme(theme)
    }

    suspend fun deleteTheme(theme: KeyboardTheme) {
        if (theme.isCustom) {
            themeDao.deleteTheme(theme)
        }
    }

    suspend fun deleteById(id: String) {
        themeDao.deleteById(id)
    }
}

package com.example

import android.content.ClipboardManager
import android.content.Context
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.lifecycleScope
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.example.data.AppDatabase
import com.example.data.clipboard.ClipboardRepository
import com.example.data.theme.ThemeRepository
import com.example.ui.screens.ClipboardHistoryScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.SettingsScreen
import com.example.ui.screens.ThemeBuilderScreen
import com.example.ui.theme.MyApplicationTheme
import com.example.util.SettingsManager
import com.example.viewmodel.ClipboardViewModel
import com.example.viewmodel.SettingsViewModel
import com.example.viewmodel.ThemeViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {

    private lateinit var settingsManager: SettingsManager
    private lateinit var clipboardViewModel: ClipboardViewModel
    private lateinit var settingsViewModel: SettingsViewModel
    private lateinit var themeViewModel: ThemeViewModel

    private var clipboardListener: ClipboardManager.OnPrimaryClipChangedListener? = null
    private lateinit var clipboardRepo: ClipboardRepository

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        // Initialize Settings, Databases & Repositories
        settingsManager = SettingsManager(this)
        val db = AppDatabase.getInstance(this)
        
        clipboardRepo = ClipboardRepository(db.clipboardDao())
        val themeRepo = ThemeRepository(db.themeDao())

        // Initialize ViewModels with Factories
        clipboardViewModel = ViewModelProvider(
            this,
            ClipboardViewModel.Factory(clipboardRepo)
        )[ClipboardViewModel::class.java]

        settingsViewModel = ViewModelProvider(
            this,
            SettingsViewModel.Factory(settingsManager)
        )[SettingsViewModel::class.java]

        themeViewModel = ViewModelProvider(
            this,
            ThemeViewModel.Factory(themeRepo)
        )[ThemeViewModel::class.java]

        setContent {
            MyApplicationTheme {
                MainLayout(
                    clipboardViewModel = clipboardViewModel,
                    settingsViewModel = settingsViewModel,
                    themeViewModel = themeViewModel
                )
            }
        }
    }

    override fun onStart() {
        super.onStart()
        // Capture copies in real-time when MainActivity is active in foreground
        val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as? ClipboardManager
        if (clipboard != null) {
            clipboardListener = ClipboardManager.OnPrimaryClipChangedListener {
                if (settingsManager.isClipboardEnabled) {
                    val clip = clipboard.primaryClip
                    if (clip != null && clip.itemCount > 0) {
                        val text = clip.getItemAt(0).text?.toString()
                        if (!text.isNullOrEmpty()) {
                            lifecycleScope.launch(Dispatchers.IO) {
                                clipboardRepo.insertText(text)
                            }
                        }
                    }
                }
            }
            clipboard.addPrimaryClipChangedListener(clipboardListener)
        }
    }

    override fun onStop() {
        super.onStop()
        val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as? ClipboardManager
        if (clipboard != null && clipboardListener != null) {
            clipboard.removePrimaryClipChangedListener(clipboardListener)
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainLayout(
    clipboardViewModel: ClipboardViewModel,
    settingsViewModel: SettingsViewModel,
    themeViewModel: ThemeViewModel
) {
    val navController = rememberNavController()
    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = navBackStackEntry?.destination?.route ?: "home"

    val titleMap = mapOf(
        "home" to "Clipboard Keyboard",
        "settings" to "Settings & Tema",
        "history" to "Manage History",
        "theme_builder" to "Custom Theme Builder"
    )

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = titleMap[currentRoute] ?: "Clipboard Keyboard",
                        fontWeight = FontWeight.Bold
                    )
                },
                navigationIcon = {
                    if (currentRoute != "home") {
                        IconButton(onClick = { navController.popBackStack() }) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                                contentDescription = "Kembali"
                            )
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primaryContainer,
                    titleContentColor = MaterialTheme.colorScheme.onPrimaryContainer,
                    navigationIconContentColor = MaterialTheme.colorScheme.onPrimaryContainer
                )
            )
        }
    ) { innerPadding ->
        NavHost(
            navController = navController,
            startDestination = "home",
            modifier = Modifier.padding(innerPadding)
        ) {
            composable("home") {
                HomeScreen(
                    clipboardViewModel = clipboardViewModel,
                    settingsViewModel = settingsViewModel,
                    themeViewModel = themeViewModel,
                    onNavigateToSettings = { navController.navigate("settings") },
                    onNavigateToHistory = { navController.navigate("history") }
                )
            }
            composable("settings") {
                SettingsScreen(
                    settingsViewModel = settingsViewModel,
                    themeViewModel = themeViewModel,
                    onNavigateToHistory = { navController.navigate("history") },
                    onNavigateToThemeBuilder = { navController.navigate("theme_builder") }
                )
            }
            composable("history") {
                ClipboardHistoryScreen(viewModel = clipboardViewModel)
            }
            composable("theme_builder") {
                ThemeBuilderScreen(
                    themeViewModel = themeViewModel,
                    onThemeSaved = {
                        navController.popBackStack()
                    }
                )
            }
        }
    }
}

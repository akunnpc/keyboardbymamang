package com.example.ui.screens

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.Save
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.viewmodel.ThemeViewModel

@Composable
fun ThemeBuilderScreen(
    themeViewModel: ThemeViewModel,
    onThemeSaved: () -> Unit
) {
    val context = LocalContext.current

    var themeName by remember { mutableStateOf("") }

    // Color States (stored as Red, Green, Blue floats for sliders)
    var bgRed by remember { mutableFloatStateOf(26f) }
    var bgGreen by remember { mutableFloatStateOf(26f) }
    var bgBlue by remember { mutableFloatStateOf(26f) }

    var keyRed by remember { mutableFloatStateOf(45f) }
    var keyGreen by remember { mutableFloatStateOf(45f) }
    var keyBlue by remember { mutableFloatStateOf(45f) }

    var textRed by remember { mutableFloatStateOf(255f) }
    var textGreen by remember { mutableFloatStateOf(255f) }
    var textBlue by remember { mutableFloatStateOf(255f) }

    var accentRed by remember { mutableFloatStateOf(79f) }
    var accentGreen by remember { mutableFloatStateOf(195f) }
    var accentBlue by remember { mutableFloatStateOf(247f) }

    // Derived Colors
    val bgColor = Color(bgRed.toInt(), bgGreen.toInt(), bgBlue.toInt())
    val keyColor = Color(keyRed.toInt(), keyGreen.toInt(), keyBlue.toInt())
    val textColor = Color(textRed.toInt(), textGreen.toInt(), textBlue.toInt())
    val accentColor = Color(accentRed.toInt(), accentGreen.toInt(), accentBlue.toInt())

    // Active color selector type
    var activeColorType by remember { mutableStateOf(ColorType.BACKGROUND) }

    val presetColors = listOf(
        Color(0xFF1A1A1A), Color(0xFFF5F5F5), Color(0xFF0D0114), Color(0xFFFDF6E3),
        Color(0xFF2196F3), Color(0xFF4CAF50), Color(0xFFFFE082), Color(0xFFFF2E9A),
        Color(0xFFFFFFFF), Color(0xFF000000), Color(0xFF00FFF0), Color(0xFFB58900)
    )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text(
            text = "Custom Theme Builder",
            style = MaterialTheme.typography.titleLarge,
            fontWeight = FontWeight.Bold
        )

        // Live Keyboard Preview
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f))
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(12.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = "PREVIEW KEYBOARD",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f),
                    modifier = Modifier.padding(bottom = 8.dp)
                )

                // The Simulated Keyboard Layout View
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .background(bgColor)
                        .padding(vertical = 10.dp, horizontal = 4.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    // Row 1: q w e r t y
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        listOf("q", "w", "e", "r", "t", "y").forEach { char ->
                            SimulatedKey(text = char, bgColor = keyColor, textColor = textColor, modifier = Modifier.weight(1f))
                        }
                    }

                    // Row 2: Shift, a, s, Backspace
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        SimulatedKey(text = "⇧", bgColor = keyColor, textColor = textColor, modifier = Modifier.weight(1.3f))
                        SimulatedKey(text = "a", bgColor = keyColor, textColor = textColor, modifier = Modifier.weight(1f))
                        SimulatedKey(text = "s", bgColor = keyColor, textColor = textColor, modifier = Modifier.weight(1f))
                        SimulatedKey(text = "⌫", bgColor = keyColor, textColor = textColor, modifier = Modifier.weight(1.3f))
                    }

                    // Row 3: ?123, Space, Enter, Clipboard
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        SimulatedKey(text = "?123", bgColor = keyColor, textColor = textColor, modifier = Modifier.weight(1.5f))
                        SimulatedKey(text = "spasi", bgColor = keyColor, textColor = textColor, modifier = Modifier.weight(4f))
                        SimulatedKey(text = "↵", bgColor = accentColor, textColor = bgColor, modifier = Modifier.weight(1.5f))
                        SimulatedKey(text = "📋", bgColor = keyColor, textColor = textColor, modifier = Modifier.weight(1.2f))
                    }
                }
            }
        }

        Divider()

        // Name of Custom Theme
        OutlinedTextField(
            value = themeName,
            onValueChange = { themeName = it },
            placeholder = { Text("Masukkan nama tema custom (cth: Tema Gw)") },
            label = { Text("Nama Tema") },
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(10.dp),
            singleLine = true
        )

        // Color Target Selection Tabs
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            ColorSelectorTab(
                text = "Background",
                isSelected = activeColorType == ColorType.BACKGROUND,
                targetColor = bgColor,
                modifier = Modifier.weight(1f)
            ) { activeColorType = ColorType.BACKGROUND }
            ColorSelectorTab(
                text = "Tombol",
                isSelected = activeColorType == ColorType.KEY_BACKGROUND,
                targetColor = keyColor,
                modifier = Modifier.weight(1f)
            ) { activeColorType = ColorType.KEY_BACKGROUND }
            ColorSelectorTab(
                text = "Teks",
                isSelected = activeColorType == ColorType.KEY_TEXT,
                targetColor = textColor,
                modifier = Modifier.weight(1f)
            ) { activeColorType = ColorType.KEY_TEXT }
            ColorSelectorTab(
                text = "Aksen",
                isSelected = activeColorType == ColorType.ACCENT,
                targetColor = accentColor,
                modifier = Modifier.weight(1f)
            ) { activeColorType = ColorType.ACCENT }
        }

        // Color Sliders
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(12.dp)
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                val activeTitle = when (activeColorType) {
                    ColorType.BACKGROUND -> "Warna Background"
                    ColorType.KEY_BACKGROUND -> "Warna Tombol"
                    ColorType.KEY_TEXT -> "Warna Teks Tombol"
                    ColorType.ACCENT -> "Warna Aksen (Enter / Shift Aktif)"
                }

                Text(
                    text = "Edit: $activeTitle",
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp,
                    color = MaterialTheme.colorScheme.primary
                )

                // Get current sliders values based on active selector type
                val currentRed = when (activeColorType) {
                    ColorType.BACKGROUND -> bgRed
                    ColorType.KEY_BACKGROUND -> keyRed
                    ColorType.KEY_TEXT -> textRed
                    ColorType.ACCENT -> accentRed
                }
                val currentGreen = when (activeColorType) {
                    ColorType.BACKGROUND -> bgGreen
                    ColorType.KEY_BACKGROUND -> keyGreen
                    ColorType.KEY_TEXT -> textGreen
                    ColorType.ACCENT -> accentGreen
                }
                val currentBlue = when (activeColorType) {
                    ColorType.BACKGROUND -> bgBlue
                    ColorType.KEY_BACKGROUND -> keyBlue
                    ColorType.KEY_TEXT -> textBlue
                    ColorType.ACCENT -> accentBlue
                }

                // Red Slider
                ColorSliderRow(label = "Merah (R)", value = currentRed, color = Color.Red) { newValue ->
                    when (activeColorType) {
                        ColorType.BACKGROUND -> bgRed = newValue
                        ColorType.KEY_BACKGROUND -> keyRed = newValue
                        ColorType.KEY_TEXT -> textRed = newValue
                        ColorType.ACCENT -> accentRed = newValue
                    }
                }

                // Green Slider
                ColorSliderRow(label = "Hijau (G)", value = currentGreen, color = Color.Green) { newValue ->
                    when (activeColorType) {
                        ColorType.BACKGROUND -> bgGreen = newValue
                        ColorType.KEY_BACKGROUND -> keyGreen = newValue
                        ColorType.KEY_TEXT -> textGreen = newValue
                        ColorType.ACCENT -> accentGreen = newValue
                    }
                }

                // Blue Slider
                ColorSliderRow(label = "Biru (B)", value = currentBlue, color = Color.Blue) { newValue ->
                    when (activeColorType) {
                        ColorType.BACKGROUND -> bgBlue = newValue
                        ColorType.KEY_BACKGROUND -> keyBlue = newValue
                        ColorType.KEY_TEXT -> textBlue = newValue
                        ColorType.ACCENT -> accentBlue = newValue
                    }
                }

                Spacer(modifier = Modifier.height(6.dp))

                // Presets Palette Row
                Text("Preset Warna Cepat:", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    presetColors.take(6).forEach { color ->
                        PresetSwatch(color = color) {
                            assignActiveColor(activeColorType, color,
                                onBg = { bgRed = it.red * 255; bgGreen = it.green * 255; bgBlue = it.blue * 255 },
                                onKey = { keyRed = it.red * 255; keyGreen = it.green * 255; keyBlue = it.blue * 255 },
                                onText = { textRed = it.red * 255; textGreen = it.green * 255; textBlue = it.blue * 255 },
                                onAccent = { accentRed = it.red * 255; accentGreen = it.green * 255; accentBlue = it.blue * 255 }
                            )
                        }
                    }
                }
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    presetColors.drop(6).forEach { color ->
                        PresetSwatch(color = color) {
                            assignActiveColor(activeColorType, color,
                                onBg = { bgRed = it.red * 255; bgGreen = it.green * 255; bgBlue = it.blue * 255 },
                                onKey = { keyRed = it.red * 255; keyGreen = it.green * 255; keyBlue = it.blue * 255 },
                                onText = { textRed = it.red * 255; textGreen = it.green * 255; textBlue = it.blue * 255 },
                                onAccent = { accentRed = it.red * 255; accentGreen = it.green * 255; accentBlue = it.blue * 255 }
                            )
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Save Theme Button
        Button(
            onClick = {
                if (themeName.trim().isEmpty()) {
                    Toast.makeText(context, "Masukkan nama tema terlebih dahulu", Toast.LENGTH_SHORT).show()
                    return@Button
                }

                val bgHex = String.format("#%06X", 0xFFFFFF and bgColor.toArgb())
                val keyHex = String.format("#%06X", 0xFFFFFF and keyColor.toArgb())
                val textHex = String.format("#%06X", 0xFFFFFF and textColor.toArgb())
                val accentHex = String.format("#%06X", 0xFFFFFF and accentColor.toArgb())

                themeViewModel.saveCustomTheme(
                    name = themeName.trim(),
                    backgroundColor = bgHex,
                    keyBackgroundColor = keyHex,
                    keyTextColor = textHex,
                    accentColor = accentHex
                )

                Toast.makeText(context, "Tema '${themeName}' Berhasil Disimpan!", Toast.LENGTH_LONG).show()
                onThemeSaved()
            },
            modifier = Modifier
                .fillMaxWidth()
                .height(50.dp),
            shape = RoundedCornerShape(12.dp)
        ) {
            Icon(Icons.Default.Save, contentDescription = null)
            Spacer(modifier = Modifier.width(8.dp))
            Text("Simpan & Pasang Tema", fontWeight = FontWeight.Bold)
        }
    }
}

enum class ColorType {
    BACKGROUND, KEY_BACKGROUND, KEY_TEXT, ACCENT
}

fun assignActiveColor(
    type: ColorType,
    color: Color,
    onBg: (Color) -> Unit,
    onKey: (Color) -> Unit,
    onText: (Color) -> Unit,
    onAccent: (Color) -> Unit
) {
    when (type) {
        ColorType.BACKGROUND -> onBg(color)
        ColorType.KEY_BACKGROUND -> onKey(color)
        ColorType.KEY_TEXT -> onText(color)
        ColorType.ACCENT -> onAccent(color)
    }
}

@Composable
fun ColorSelectorTab(
    text: String,
    isSelected: Boolean,
    targetColor: Color,
    modifier: Modifier,
    onClick: () -> Unit
) {
    Column(
        modifier = modifier
            .clip(RoundedCornerShape(8.dp))
            .background(if (isSelected) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surface)
            .border(
                width = 1.dp,
                color = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline.copy(alpha = 0.3f),
                shape = RoundedCornerShape(8.dp)
            )
            .clickable { onClick() }
            .padding(vertical = 8.dp, horizontal = 4.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Box(
            modifier = Modifier
                .size(18.dp)
                .clip(CircleShape)
                .background(targetColor)
                .border(1.dp, MaterialTheme.colorScheme.onSurface.copy(alpha = 0.2f), CircleShape)
        )
        Spacer(modifier = Modifier.height(4.dp))
        Text(
            text = text,
            fontSize = 11.sp,
            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
            color = if (isSelected) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.onSurface,
            textAlign = TextAlign.Center
        )
    }
}

@Composable
fun ColorSliderRow(
    label: String,
    value: Float,
    color: Color,
    onValueChange: (Float) -> Unit
) {
    Column {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(text = label, fontSize = 12.sp, fontWeight = FontWeight.Medium)
            Text(text = value.toInt().toString(), fontSize = 12.sp, fontWeight = FontWeight.Bold, color = color)
        }
        Slider(
            value = value,
            onValueChange = onValueChange,
            valueRange = 0f..255f,
            colors = SliderDefaults.colors(
                thumbColor = color,
                activeTrackColor = color.copy(alpha = 0.6f)
            )
        )
    }
}

@Composable
fun PresetSwatch(
    color: Color,
    onClick: () -> Unit
) {
    Box(
        modifier = Modifier
            .size(34.dp)
            .clip(RoundedCornerShape(6.dp))
            .background(color)
            .border(1.dp, Color.Gray.copy(alpha = 0.3f), RoundedCornerShape(6.dp))
            .clickable { onClick() }
    )
}

@Composable
fun SimulatedKey(
    text: String,
    bgColor: Color,
    textColor: Color,
    modifier: Modifier
) {
    Box(
        modifier = modifier
            .height(30.dp)
            .clip(RoundedCornerShape(4.dp))
            .background(bgColor),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = text,
            color = textColor,
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold
        )
    }
}

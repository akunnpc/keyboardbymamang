package com.example.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.theme.KeyboardTheme
import com.example.data.theme.ThemeRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.util.UUID

class ThemeViewModel(private val repository: ThemeRepository) : ViewModel() {

    val allThemes: StateFlow<List<KeyboardTheme>> = repository.allThemes
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = KeyboardTheme.PRESETS
        )

    fun saveCustomTheme(
        name: String,
        backgroundColor: String,
        keyBackgroundColor: String,
        keyTextColor: String,
        accentColor: String
    ) {
        viewModelScope.launch(Dispatchers.IO) {
            val id = "custom_" + UUID.randomUUID().toString().take(8)
            val theme = KeyboardTheme(
                id = id,
                name = name,
                backgroundColor = backgroundColor,
                keyBackgroundColor = keyBackgroundColor,
                keyTextColor = keyTextColor,
                accentColor = accentColor,
                isCustom = true
            )
            repository.saveTheme(theme)
        }
    }

    fun deleteTheme(theme: KeyboardTheme) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.deleteTheme(theme)
        }
    }

    class Factory(private val repository: ThemeRepository) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            if (modelClass.isAssignableFrom(ThemeViewModel::class.java)) {
                return ThemeViewModel(repository) as T
            }
            throw IllegalArgumentException("Unknown ViewModel class")
        }
    }
}

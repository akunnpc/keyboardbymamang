package com.example.viewmodel

import android.content.Context
import android.net.Uri
import android.os.Environment
import android.widget.Toast
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.clipboard.ClipboardEntry
import com.example.data.clipboard.ClipboardRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class ClipboardViewModel(private val repository: ClipboardRepository) : ViewModel() {

    val searchQuery = MutableStateFlow("")

    val clipboardEntries: StateFlow<List<ClipboardEntry>> = searchQuery
        .flatMapLatest { query ->
            if (query.isEmpty()) {
                repository.allEntries
            } else {
                repository.searchEntries(query)
            }
        }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    fun updateSearchQuery(query: String) {
        searchQuery.value = query
    }

    fun insertText(text: String) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.insertText(text)
        }
    }

    fun deleteEntry(entry: ClipboardEntry) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.delete(entry)
        }
    }

    fun togglePin(entry: ClipboardEntry) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.togglePin(entry)
        }
    }

    fun clearAllUnpinned() {
        viewModelScope.launch(Dispatchers.IO) {
            repository.clearAllUnpinned()
        }
    }

    fun exportToTxt(context: Context, entries: List<ClipboardEntry>) {
        viewModelScope.launch {
            if (entries.isEmpty()) {
                Toast.makeText(context, "Tidak ada data untuk diekspor", Toast.LENGTH_SHORT).show()
                return@launch
            }

            val success = withContext(Dispatchers.IO) {
                try {
                    val sdf = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault())
                    val fileName = "Clipboard_Export_${sdf.format(Date())}.txt"
                    
                    // Save to the Downloads folder
                    val downloadsDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
                    val file = File(downloadsDir, fileName)
                    
                    val fileOutputStream = FileOutputStream(file)
                    fileOutputStream.use { stream ->
                        val itemSdf = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault())
                        for (entry in entries) {
                            val pinText = if (entry.isPinned) "[PINNED] " else ""
                            val header = "=== ${pinText}Copied on: ${itemSdf.format(Date(entry.timestamp))} ===\n"
                            stream.write(header.toByteArray())
                            stream.write(entry.fullText.toByteArray())
                            stream.write("\n\n".toByteArray())
                        }
                    }
                    true
                } catch (e: Exception) {
                    e.printStackTrace()
                    false
                }
            }

            if (success) {
                Toast.makeText(context, "Ekspor berhasil! File disimpan di folder Downloads", Toast.LENGTH_LONG).show()
            } else {
                Toast.makeText(context, "Gagal mengekspor file", Toast.LENGTH_SHORT).show()
            }
        }
    }

    class Factory(private val repository: ClipboardRepository) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            if (modelClass.isAssignableFrom(ClipboardViewModel::class.java)) {
                return ClipboardViewModel(repository) as T
            }
            throw IllegalArgumentException("Unknown ViewModel class")
        }
    }
}

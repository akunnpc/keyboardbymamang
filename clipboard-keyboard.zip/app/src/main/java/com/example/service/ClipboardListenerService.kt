package com.example.service

import android.app.Service
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.os.IBinder
import android.util.Log
import com.example.data.AppDatabase
import com.example.data.clipboard.ClipboardRepository
import com.example.util.SettingsManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

/**
 * ClipboardListenerService is kept to fulfill the requested project structure.
 * Note: On Android 10+ (API 29+), background services cannot read the clipboard.
 * Thus, clipboard monitoring is primarily handled directly inside MainActivity
 * and CustomKeyboardService when they are in the active foreground or input focus.
 */
class ClipboardListenerService : Service() {

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private lateinit var clipboardRepo: ClipboardRepository
    private lateinit var settingsManager: SettingsManager
    private var clipboardListener: ClipboardManager.OnPrimaryClipChangedListener? = null

    override fun onCreate() {
        super.onCreate()
        Log.d("ClipboardService", "Service created.")
        settingsManager = SettingsManager(this)
        val db = AppDatabase.getInstance(this)
        clipboardRepo = ClipboardRepository(db.clipboardDao())

        val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as? ClipboardManager
        if (clipboard != null) {
            clipboardListener = ClipboardManager.OnPrimaryClipChangedListener {
                if (settingsManager.isClipboardEnabled) {
                    val clip = clipboard.primaryClip
                    if (clip != null && clip.itemCount > 0) {
                        val text = clip.getItemAt(0).text?.toString()
                        if (!text.isNullOrEmpty()) {
                            serviceScope.launch {
                                clipboardRepo.insertText(text)
                            }
                        }
                    }
                }
            }
            clipboard.addPrimaryClipChangedListener(clipboardListener)
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        return START_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? {
        return null
    }

    override fun onDestroy() {
        super.onDestroy()
        val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as? ClipboardManager
        if (clipboard != null && clipboardListener != null) {
            clipboard.removePrimaryClipChangedListener(clipboardListener)
        }
    }
}

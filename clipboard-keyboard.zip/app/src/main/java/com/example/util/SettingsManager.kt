package com.example.util

import android.content.Context
import android.content.SharedPreferences

class SettingsManager(context: Context) {
    private val prefs: SharedPreferences = context.getSharedPreferences(
        "custom_keyboard_settings",
        Context.MODE_PRIVATE
    )

    companion object {
        private const val KEY_CLIPBOARD_ENABLED = "clipboard_enabled"
        private const val KEY_AUTO_DELETE_DAYS = "auto_delete_days"
        private const val KEY_SELECTED_THEME_ID = "selected_theme_id"
    }

    var isClipboardEnabled: Boolean
        get() = prefs.getBoolean(KEY_CLIPBOARD_ENABLED, true)
        set(value) = prefs.edit().putBoolean(KEY_CLIPBOARD_ENABLED, value).apply()

    var autoDeleteDays: Int
        get() = prefs.getInt(KEY_AUTO_DELETE_DAYS, -1) // -1 means Never
        set(value) = prefs.edit().putInt(KEY_AUTO_DELETE_DAYS, value).apply()

    var selectedThemeId: String
        get() = prefs.getString(KEY_SELECTED_THEME_ID, "dark_minimal") ?: "dark_minimal"
        set(value) = prefs.edit().putString(KEY_SELECTED_THEME_ID, value).apply()
}

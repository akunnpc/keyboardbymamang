package com.example.keyboard

import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.RippleDrawable
import android.content.res.ColorStateList
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView
import com.example.data.theme.KeyboardTheme

class KeyboardView(
    context: Context,
    private val theme: KeyboardTheme,
    private val listener: KeyboardActionListener
) : LinearLayout(context) {

    interface KeyboardActionListener {
        fun onKeyText(text: String)
        fun onBackspace()
        fun onShiftToggle()
        fun onEnter()
        fun onSpace()
    }

    private var currentMode = KeyboardMode.ABC
    private var isShifted = false

    private val keyboardContainer: LinearLayout

    enum class KeyboardMode {
        ABC, SYMBOLS, EMOJIS
    }

    init {
        orientation = VERTICAL
        layoutParams = LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT)
        setBackgroundColor(Color.parseColor(theme.backgroundColor))
        setPadding(0, dpToPx(6), 0, dpToPx(6))

        keyboardContainer = LinearLayout(context).apply {
            orientation = VERTICAL
            layoutParams = LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT)
        }
        addView(keyboardContainer)

        buildKeyboard()
    }

    private fun buildKeyboard() {
        keyboardContainer.removeAllViews()

        val rows = when (currentMode) {
            KeyboardMode.ABC -> if (isShifted) KeyboardLayout.qwertyRowsShifted else KeyboardLayout.qwertyRows
            KeyboardMode.SYMBOLS -> KeyboardLayout.symbolRows
            KeyboardMode.EMOJIS -> KeyboardLayout.emojiRows
        }

        for (row in rows) {
            val rowLayout = LinearLayout(context).apply {
                orientation = HORIZONTAL
                gravity = Gravity.CENTER
                layoutParams = LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT)
            }

            for (key in row) {
                val keyView = createKeyView(key)
                rowLayout.addView(keyView)
            }

            keyboardContainer.addView(rowLayout)
        }
    }

    private fun createKeyView(key: String): View {
        val button = TextView(context).apply {
            gravity = Gravity.CENTER
            textSize = 18f
            typeface = Typeface.DEFAULT_BOLD
            setPadding(0, dpToPx(12), 0, dpToPx(12))
        }

        // Apply theme colors & ripple
        val normalColor = Color.parseColor(theme.keyBackgroundColor)
        val pressedColor = Color.parseColor(theme.keyTextColor).adjustAlpha(0.2f)
        val accentColor = Color.parseColor(theme.accentColor)

        val baseDrawable = GradientDrawable().apply {
            cornerRadius = dpToPx(6).toFloat()
            setColor(normalColor)
        }

        val keyBg = RippleDrawable(
            ColorStateList.valueOf(pressedColor),
            baseDrawable,
            null
        )

        button.background = keyBg
        button.setTextColor(Color.parseColor(theme.keyTextColor))

        var weight = 1f
        var displayText = key

        when (key) {
            "[SHIFT]" -> {
                displayText = "⇧"
                weight = 1.4f
                button.setOnClickListener {
                    isShifted = !isShifted
                    buildKeyboard()
                    listener.onShiftToggle()
                }
            }
            "[SHIFT_ACTIVE]" -> {
                displayText = "⇪"
                weight = 1.4f
                val activeBg = GradientDrawable().apply {
                    cornerRadius = dpToPx(6).toFloat()
                    setColor(accentColor)
                }
                button.background = RippleDrawable(ColorStateList.valueOf(pressedColor), activeBg, null)
                button.setTextColor(Color.parseColor(theme.backgroundColor))
                button.setOnClickListener {
                    isShifted = false
                    buildKeyboard()
                    listener.onShiftToggle()
                }
            }
            "[BACKSPACE]" -> {
                displayText = "⌫"
                weight = 1.4f
                button.setOnClickListener {
                    listener.onBackspace()
                }
            }
            "[SWITCH_123]" -> {
                displayText = "?123"
                weight = 1.5f
                button.setOnClickListener {
                    currentMode = KeyboardMode.SYMBOLS
                    buildKeyboard()
                }
            }
            "[SWITCH_ABC]" -> {
                displayText = "abc"
                weight = 1.5f
                button.setOnClickListener {
                    currentMode = KeyboardMode.ABC
                    buildKeyboard()
                }
            }
            "[SWITCH_EMOJI]" -> {
                displayText = "☺"
                weight = 1.2f
                button.setOnClickListener {
                    currentMode = KeyboardMode.EMOJIS
                    buildKeyboard()
                }
            }
            "[SPACE]" -> {
                displayText = "spasi"
                weight = 4.0f
                button.setOnClickListener {
                    listener.onSpace()
                }
            }
            "[ENTER]" -> {
                displayText = "↵"
                weight = 1.5f
                val enterBg = GradientDrawable().apply {
                    cornerRadius = dpToPx(6).toFloat()
                    setColor(accentColor)
                }
                button.background = RippleDrawable(ColorStateList.valueOf(pressedColor), enterBg, null)
                button.setTextColor(Color.parseColor(theme.backgroundColor))
                button.setOnClickListener {
                    listener.onEnter()
                }
            }
            "[CLIPBOARD]" -> {
                displayText = "📋"
                weight = 1.2f
                button.setOnClickListener {
                    showClipboardPanel()
                }
            }
            else -> {
                button.setOnClickListener {
                    listener.onKeyText(key)
                }
            }
        }

        button.text = displayText

        val lp = LayoutParams(0, dpToPx(48)).apply {
            this.weight = weight
            topMargin = dpToPx(4)
            bottomMargin = dpToPx(4)
            leftMargin = dpToPx(4)
            rightMargin = dpToPx(4)
        }
        button.layoutParams = lp

        return button
    }

    private fun showClipboardPanel() {
        keyboardContainer.visibility = View.GONE
        
        val clipboardPanel = ClipboardPanelView(
            context = context,
            theme = theme,
            onPaste = { text ->
                listener.onKeyText(text)
            },
            onClose = {
                // Remove panel and restore main keyboard keys
                val lastChild = getChildAt(childCount - 1)
                if (lastChild is ClipboardPanelView) {
                    removeView(lastChild)
                }
                keyboardContainer.visibility = View.VISIBLE
            }
        )
        
        addView(clipboardPanel)
    }

    private fun dpToPx(dp: Int): Int {
        return TypedValue.applyDimension(
            TypedValue.COMPLEX_UNIT_DIP,
            dp.toFloat(),
            context.resources.displayMetrics
        ).toInt()
    }

    private fun Int.adjustAlpha(factor: Float): Int {
        val alpha = Math.round(Color.alpha(this) * factor)
        val red = Color.red(this)
        val green = Color.green(this)
        val blue = Color.blue(this)
        return Color.argb(alpha, red, green, blue)
    }
}

package com.example.keyboard

import android.app.AlertDialog
import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.text.Editable
import android.text.TextWatcher
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.EditText
import android.widget.HorizontalScrollView
import android.widget.ImageButton
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import com.example.data.AppDatabase
import com.example.data.clipboard.ClipboardEntry
import com.example.data.theme.KeyboardTheme
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class ClipboardPanelView(
    context: Context,
    private val theme: KeyboardTheme,
    private val onPaste: (String) -> Unit,
    private val onClose: () -> Unit
) : LinearLayout(context) {

    private val db = AppDatabase.getInstance(context)
    private val viewScope = CoroutineScope(Dispatchers.Main + Job())

    private lateinit var searchInput: EditText
    private lateinit var itemsContainer: LinearLayout
    private lateinit var emptyTextView: TextView
    private var allEntries: List<ClipboardEntry> = emptyList()

    init {
        orientation = VERTICAL
        layoutParams = LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT)
        setBackgroundColor(Color.parseColor(theme.backgroundColor))

        // Create Header Row (Search & Action Buttons)
        createHeaderRow()

        // Create ScrollView for clipboard list
        createContentArea()

        // Load Clipboard entries
        loadEntries()
    }

    private fun createHeaderRow() {
        val header = LinearLayout(context).apply {
            orientation = HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dpToPx(8), dpToPx(6), dpToPx(8), dpToPx(6))
        }

        // Close button
        val closeBtn = TextView(context).apply {
            text = "✕"
            textSize = 18f
            setTextColor(Color.parseColor(theme.keyTextColor))
            setPadding(dpToPx(10), dpToPx(6), dpToPx(10), dpToPx(6))
            setOnClickListener { onClose() }
        }
        header.addView(closeBtn)

        // Search Input
        searchInput = EditText(context).apply {
            hint = "Cari clipboard..."
            setHintTextColor(Color.parseColor(theme.keyTextColor).adjustAlpha(0.5f))
            setTextColor(Color.parseColor(theme.keyTextColor))
            textSize = 14f
            background = GradientDrawable().apply {
                setColor(Color.parseColor(theme.keyBackgroundColor))
                cornerRadius = dpToPx(8).toFloat()
            }
            setPadding(dpToPx(12), dpToPx(8), dpToPx(12), dpToPx(8))
            val lp = LayoutParams(0, LayoutParams.WRAP_CONTENT, 1f).apply {
                leftMargin = dpToPx(8)
                rightMargin = dpToPx(8)
            }
            layoutParams = lp

            addTextChangedListener(object : TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
                override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                    filterList(s?.toString() ?: "")
                }
                override fun afterTextChanged(s: Editable?) {}
            })
        }
        header.addView(searchInput)

        // Hapus Semua Button
        val clearAllBtn = TextView(context).apply {
            text = "Hapus Semua"
            textSize = 12f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.parseColor(theme.accentColor))
            setPadding(dpToPx(8), dpToPx(6), dpToPx(8), dpToPx(6))
            setOnClickListener {
                showDeleteAllConfirmation()
            }
        }
        header.addView(clearAllBtn)

        addView(header)
    }

    private fun createContentArea() {
        val scrollView = ScrollView(context).apply {
            layoutParams = LayoutParams(LayoutParams.MATCH_PARENT, 0, 1f)
            isVerticalScrollBarEnabled = true
        }

        itemsContainer = LinearLayout(context).apply {
            orientation = VERTICAL
            setPadding(dpToPx(8), dpToPx(4), dpToPx(8), dpToPx(8))
        }

        emptyTextView = TextView(context).apply {
            text = "Clipboard History Kosong"
            gravity = Gravity.CENTER
            setTextColor(Color.parseColor(theme.keyTextColor).adjustAlpha(0.4f))
            textSize = 14f
            setPadding(0, dpToPx(40), 0, dpToPx(40))
            visibility = View.GONE
        }

        scrollView.addView(itemsContainer)
        addView(scrollView)
        addView(emptyTextView)
    }

    private fun loadEntries() {
        viewScope.launch {
            db.clipboardDao().getAllEntries().collectLatest { entries ->
                allEntries = entries
                filterList(searchInput.text.toString())
            }
        }
    }

    private fun filterList(query: String) {
        itemsContainer.removeAllViews()
        val filtered = if (query.isEmpty()) {
            allEntries
        } else {
            allEntries.filter { it.fullText.contains(query, ignoreCase = true) }
        }

        if (filtered.isEmpty()) {
            emptyTextView.visibility = View.VISIBLE
            emptyTextView.text = if (query.isEmpty()) "Clipboard History Kosong" else "Hasil pencarian tidak ditemukan"
        } else {
            emptyTextView.visibility = View.GONE
            for (entry in filtered) {
                val itemCard = createItemCard(entry)
                itemsContainer.addView(itemCard)
            }
        }
    }

    private fun createItemCard(entry: ClipboardEntry): View {
        val container = LinearLayout(context).apply {
            orientation = VERTICAL
            setPadding(dpToPx(12), dpToPx(10), dpToPx(12), dpToPx(10))
            background = GradientDrawable().apply {
                setColor(Color.parseColor(theme.keyBackgroundColor))
                cornerRadius = dpToPx(8).toFloat()
                if (entry.isPinned) {
                    setStroke(dpToPx(1), Color.parseColor(theme.accentColor))
                }
            }
            val lp = LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT).apply {
                bottomMargin = dpToPx(6)
            }
            layoutParams = lp

            setOnClickListener {
                onPaste(entry.fullText)
            }

            setOnLongClickListener {
                showItemOptions(entry)
                true
            }
        }

        // Header line: time and PIN status
        val metaRow = LinearLayout(context).apply {
            orientation = HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            val lp = LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT).apply {
                bottomMargin = dpToPx(4)
            }
            layoutParams = lp
        }

        val timeView = TextView(context).apply {
            val sdf = SimpleDateFormat("HH:mm - dd MMM", Locale.getDefault())
            text = sdf.format(Date(entry.timestamp))
            textSize = 10f
            setTextColor(Color.parseColor(theme.keyTextColor).adjustAlpha(0.5f))
            layoutParams = LayoutParams(0, LayoutParams.WRAP_CONTENT, 1f)
        }
        metaRow.addView(timeView)

        if (entry.isPinned) {
            val pinView = TextView(context).apply {
                text = "📌 TERPIN"
                textSize = 9f
                typeface = Typeface.DEFAULT_BOLD
                setTextColor(Color.parseColor(theme.accentColor))
            }
            metaRow.addView(pinView)
        }
        container.addView(metaRow)

        // Preview text
        val previewView = TextView(context).apply {
            text = entry.previewText
            maxLines = 2
            textSize = 13f
            setTextColor(Color.parseColor(theme.keyTextColor))
        }
        container.addView(previewView)

        return container
    }

    private fun showItemOptions(entry: ClipboardEntry) {
        // Build a highly stable inline or Alert Options Menu that works on any IME view
        val options = arrayOf(
            if (entry.isPinned) "Lepas Pin (Unpin)" else "Sematkan (Pin)",
            "Salin Lagi (Copy)",
            "Hapus"
        )

        // Show standard AlertDialog but force the input method window token to allow it
        val builder = AlertDialog.Builder(context)
        builder.setTitle("Opsi Clipboard")
        builder.setItems(options) { _, which ->
            when (which) {
                0 -> { // Pin/Unpin
                    viewScope.launch {
                        db.clipboardDao().insertEntry(entry.copy(isPinned = !entry.isPinned))
                    }
                }
                1 -> { // Copy
                    val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
                    val clip = android.content.ClipData.newPlainText("Copied Text", entry.fullText)
                    clipboard.setPrimaryClip(clip)
                    Toast.makeText(context, "Disalin ke clipboard", Toast.LENGTH_SHORT).show()
                }
                2 -> { // Delete
                    viewScope.launch {
                        db.clipboardDao().deleteEntry(entry)
                    }
                }
            }
        }

        val dialog = builder.create()
        // Crucial IME setting so standard dialog can show without crashing inside InputMethodService context
        dialog.window?.let { window ->
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
                window.setType(WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY)
            } else {
                @Suppress("DEPRECATION")
                window.setType(WindowManager.LayoutParams.TYPE_SYSTEM_ALERT)
            }
        }
        
        try {
            dialog.show()
        } catch (e: Exception) {
            // Fallback in case permission is not given or TYPE_APPLICATION_OVERLAY fails in background
            // We can show a beautiful toast or use an inline overlay in the keyboard
            showInlineOptions(entry)
        }
    }

    private fun showInlineOptions(entry: ClipboardEntry) {
        // Quick Toast for user instruction, and then perform a default toggle pin on long press to make it incredibly direct!
        viewScope.launch {
            db.clipboardDao().insertEntry(entry.copy(isPinned = !entry.isPinned))
            val msg = if (entry.isPinned) "Pin dilepas" else "Item di-Pin ke atas"
            Toast.makeText(context, "$msg (Gunakan long-press untuk Pin/Unpin cepat)", Toast.LENGTH_SHORT).show()
        }
    }

    private fun showDeleteAllConfirmation() {
        val builder = AlertDialog.Builder(context)
        builder.setTitle("Hapus Semua History?")
        builder.setMessage("Teks clipboard yang di-pin tidak akan dihapus.")
        builder.setPositiveButton("Hapus") { _, _ ->
            viewScope.launch {
                db.clipboardDao().deleteAllUnpinned()
                Toast.makeText(context, "Clipboard dibersihkan", Toast.LENGTH_SHORT).show()
            }
        }
        builder.setNegativeButton("Batal", null)

        val dialog = builder.create()
        dialog.window?.let { window ->
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
                window.setType(WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY)
            } else {
                @Suppress("DEPRECATION")
                window.setType(WindowManager.LayoutParams.TYPE_SYSTEM_ALERT)
            }
        }
        try {
            dialog.show()
        } catch (e: Exception) {
            // Fallback: delete directly if dialog cannot show
            viewScope.launch {
                db.clipboardDao().deleteAllUnpinned()
                Toast.makeText(context, "Semua history tidak di-pin dihapus", Toast.LENGTH_SHORT).show()
            }
        }
    }

    override fun onDetachedFromWindow() {
        super.onDetachedFromWindow()
        viewScope.cancel()
    }

    private fun dpToPx(dp: Int): Int {
        return TypedValue.applyDimension(
            TypedValue.COMPLEX_UNIT_DIP,
            dp.toFloat(),
            context.resources.displayMetrics
        ).toInt()
    }

    private fun Int.adjustAlpha(factor: Float): Int {
        val alpha = Math.round(Color.alpha(this) * factor)
        val red = Color.red(this)
        val green = Color.green(this)
        val blue = Color.blue(this)
        return Color.argb(alpha, red, green, blue)
    }
}

package com.example.keyboard

object KeyboardLayout {
    val qwertyRows = listOf(
        listOf("q", "w", "e", "r", "t", "y", "u", "i", "o", "p"),
        listOf("a", "s", "d", "f", "g", "h", "j", "k", "l"),
        listOf("[SHIFT]", "z", "x", "c", "v", "b", "n", "m", "[BACKSPACE]"),
        listOf("[SWITCH_123]", "[SWITCH_EMOJI]", "[SPACE]", "[ENTER]", "[CLIPBOARD]")
    )

    val qwertyRowsShifted = listOf(
        listOf("Q", "W", "E", "R", "T", "Y", "U", "I", "O", "P"),
        listOf("A", "S", "D", "F", "G", "H", "J", "K", "L"),
        listOf("[SHIFT_ACTIVE]", "Z", "X", "C", "V", "B", "N", "M", "[BACKSPACE]"),
        listOf("[SWITCH_123]", "[SWITCH_EMOJI]", "[SPACE]", "[ENTER]", "[CLIPBOARD]")
    )

    val symbolRows = listOf(
        listOf("1", "2", "3", "4", "5", "6", "7", "8", "9", "0"),
        listOf("@", "#", "$", "%", "&", "*", "-", "+", "(", ")"),
        listOf("[SWITCH_ABC]", "!", "\"", "'", ":", ";", "/", "?", "[BACKSPACE]"),
        listOf("[SWITCH_ABC]", "[SWITCH_EMOJI]", "[SPACE]", "[ENTER]", "[CLIPBOARD]")
    )

    val emojiRows = listOf(
        listOf("😀", "😂", "😍", "👍", "🙏", "🔥", "❤️", "🎉", "🚀"),
        listOf("💡", "👏", "🤔", "😢", "😎", "🌟", "💯", "👀", "💀"),
        listOf("[SWITCH_ABC]", "✨", "✌️", "ok", "sys", "bye", "wtf", "lol", "[BACKSPACE]"),
        listOf("[SWITCH_ABC]", "[SWITCH_123]", "[SPACE]", "[ENTER]", "[CLIPBOARD]")
    )
}

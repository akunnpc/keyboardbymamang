# Clipboard Keyboard 📋

A modern, offline-first Android custom keyboard (Input Method Editor) written in Kotlin and Jetpack Compose. It features a fully featured standard QWERTY layout, dynamic keyboard styling themes, a custom color theme builder with real-time preview, and an unlimited searchable clipboard history manager.

## Key Features

1. **Custom Keyboard IME**: Built purely on Android's native `InputMethodService` for rock-solid stability and zero third-party dependencies.
2. **QWERTY Layout**: Complete standard English letters, switchable number/symbol rows, and an inline popular emoji pad.
3. **Unlimited Clipboard History**: Automatically tracks copies while the keyboard or the main app is active, storing entries inside an offline-first **Room SQLite Database**. Supports pinning, deleting individual or all unpinned entries, and searching clips by text.
4. **Interactive Theme Selection**: Select from 4 highly-polished presets (Dark Minimal, Light Clean, Neon Cyberpunk, Solarized Sepia) or construct your own custom themes using our **Custom Theme Builder** with slider-driven controls and a live real-time visual preview!
5. **Privacy Guarded**: 100% offline with zero network connectivity or telemetry, ensuring your passwords, links, and private copy data never leave your device.
6. **Data Exporter**: Cleanly compile and export your clipboard history into a readable `.txt` file inside your device's `Downloads` directory.

---

## How to Install & Activate

### Step 1: Compile the APK
If compiling locally, simply execute:
```bash
./gradlew assembleDebug
```
The compiled APK will be located at:
`app/build/outputs/apk/debug/app-debug.apk`

*Alternatively, push this repository to GitHub, and the included GitHub Actions workflow will automatically compile the APK and attach it to your workflow run artifacts!*

### Step 2: Enable the Keyboard
1. Install and open the **Clipboard Keyboard** launcher app.
2. Tap **"1. Aktifkan di Settings"** to open your Android System Virtual Keyboard Settings.
3. Find and toggle **Clipboard Keyboard** to **ON**.

### Step 3: Select as Default
1. Tap **"2. Pilih Keyboard Default"** (or tap the keyboard icon at the bottom of your screen when typing).
2. Select **Clipboard Keyboard** as your active input method.

---

## Tech Stack
* **Language**: Kotlin 100%
* **UI**: Jetpack Compose (Launcher app, Theme Builder, History screens)
* **Keyboard Engine**: Native View-based `InputMethodService` (for maximum performance and crash prevention)
* **Local Persistence**: Room SQLite Database
* **CI/CD**: GitHub Actions

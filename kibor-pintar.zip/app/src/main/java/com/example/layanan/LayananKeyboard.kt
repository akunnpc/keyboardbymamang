package com.example.layanan

import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.inputmethodservice.InputMethodService
import android.view.View
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.platform.ComposeView
import androidx.lifecycle.*
import androidx.savedstate.setViewTreeSavedStateRegistryOwner
import androidx.savedstate.SavedStateRegistry
import androidx.savedstate.SavedStateRegistryController
import androidx.savedstate.SavedStateRegistryOwner
import com.example.database.BasisDataClipboard
import com.example.database.EntitasClipboard
import com.example.database.RepositoriClipboard
import com.example.keyboard.TampilanKeyboard
import com.example.pengaturan.PenyimpananPengaturan
import com.example.utilitas.AlatGetar
import com.example.utilitas.AlatSuara
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

class LayananKeyboard : InputMethodService(), LifecycleOwner, ViewModelStoreOwner, SavedStateRegistryOwner {
    private val pendaftarSiklusHidup = LifecycleRegistry(this)
    private val penyimpananViewModel = ViewModelStore()
    private val pengontrolRegistry = SavedStateRegistryController.create(this)

    override val lifecycle: Lifecycle get() = pendaftarSiklusHidup
    override val viewModelStore: ViewModelStore get() = penyimpananViewModel
    override val savedStateRegistry: SavedStateRegistry get() = pengontrolRegistry.savedStateRegistry

    private val lingkupPekerjaan = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private lateinit var repositori: RepositoriClipboard
    private lateinit var setelan: PenyimpananPengaturan
    private lateinit var helperGetar: AlatGetar
    private lateinit var helperSuara: AlatSuara

    private val daftarClipboardNegara = MutableStateFlow<List<EntitasClipboard>>(emptyList())

    override fun onCreate() {
        super.onCreate()
        pendaftarSiklusHidup.handleLifecycleEvent(Lifecycle.Event.ON_CREATE)
        pengontrolRegistry.performRestore(null)

        val database = BasisDataClipboard.dapatkanInstansi(this)
        repositori = RepositoriClipboard(database.aksesDataClipboard())
        setelan = PenyimpananPengaturan(this)
        helperGetar = AlatGetar(this)
        helperSuara = AlatSuara(this)

        lingkupPekerjaan.launch {
            repositori.semuaClipboard.collectLatest { daftar ->
                daftarClipboardNegara.value = daftar
            }
        }
    }

    override fun onStartInputView(info: android.view.inputmethod.EditorInfo?, restarting: Boolean) {
        super.onStartInputView(info, restarting)
        pendaftarSiklusHidup.handleLifecycleEvent(Lifecycle.Event.ON_START)
        periksaDanSimpanClipboardPerangkat()
    }

    override fun onFinishInputView(finishingInput: Boolean) {
        super.onFinishInputView(finishingInput)
        pendaftarSiklusHidup.handleLifecycleEvent(Lifecycle.Event.ON_STOP)
    }

    override fun onCreateInputView(): View {
        val tampilanKiborCompose = ComposeView(this).apply {
            setViewTreeLifecycleOwner(this@LayananKeyboard)
            setViewTreeViewModelStoreOwner(this@LayananKeyboard)
            setViewTreeSavedStateRegistryOwner(this@LayananKeyboard)
        }

        tampilanKiborCompose.setContent {
            val daftarSemuaKlip by daftarClipboardNegara.collectAsState()

            TampilanKeyboard(
                daftarClipboard = daftarSemuaKlip,
                tinggiKiborDp = setelan.tinggiKeyboardDlmDp,
                ukuranHurufSp = setelan.ukuranHurufTombolSp,
                apakahGetarAktif = setelan.apakahGetarAktif,
                apakahSuaraAktif = setelan.apakahSuaraAktif,
                getarHelper = helperGetar,
                suaraHelper = helperSuara,
                onTekanTombol = { teks ->
                    when (teks) {
                        "\n" -> kirimAksiEnter()
                        " " -> tanganiKetikKarakter(" ")
                        else -> tanganiKetikKarakter(teks)
                    }
                },
                onHapusSatuKarakter = {
                    tanganiHapusKarakter()
                },
                onBukaPengaturan = {
                    bukaAplikasiUtama()
                },
                onUbahPin = { idClipboard, statusPin ->
                    lingkupPekerjaan.launch {
                        val itemLama = daftarSemuaKlip.find { it.idClipboard == idClipboard }
                        if (itemLama != null) {
                            repositori.simpan(itemLama.copy(apakahDiPin = statusPin))
                        }
                    }
                },
                onUbahFavorit = { idClipboard, statusFavorit ->
                    lingkupPekerjaan.launch {
                        val itemLama = daftarSemuaKlip.find { it.idClipboard == idClipboard }
                        if (itemLama != null) {
                            repositori.simpan(itemLama.copy(apakahFavorit = statusFavorit))
                        }
                    }
                },
                onHapusClipboard = { idClipboard ->
                    lingkupPekerjaan.launch {
                        repositori.hapus(idClipboard)
                    }
                }
            )
        }

        return tampilanKiborCompose
    }

    private fun tanganiKetikKarakter(teks: String) {
        val koneksiInput = currentInputConnection
        koneksiInput?.commitText(teks, 1)
    }

    private fun tanganiHapusKarakter() {
        val koneksiInput = currentInputConnection
        koneksiInput?.deleteSurroundingText(1, 0)
    }

    private fun kirimAksiEnter() {
        val koneksiInput = currentInputConnection ?: return
        val infoEditor = currentInputEditorInfo
        if (infoEditor != null) {
            val idAksi = infoEditor.actionId
            if (idAksi != 0) {
                koneksiInput.performEditorAction(idAksi)
                return
            }
        }
        koneksiInput.commitText("\n", 1)
    }

    private fun periksaDanSimpanClipboardPerangkat() {
        val pengelolaClipboard = getSystemService(Context.CLIPBOARD_SERVICE) as? ClipboardManager ?: return
        val dataKlip = pengelolaClipboard.primaryClip
        if (dataKlip != null && dataKlip.itemCount > 0) {
            val teksKlip = dataKlip.getItemAt(0).text?.toString()
            if (!teksKlip.isNullOrBlank()) {
                val daftarSaatIni = daftarClipboardNegara.value
                val apakahSudahAda = daftarSaatIni.any { it.teksClipboard == teksKlip }
                if (!apakahSudahAda) {
                    lingkupPekerjaan.launch {
                        repositori.simpan(EntitasClipboard(teksClipboard = teksKlip))
                    }
                }
            }
        }
    }

    private fun bukaAplikasiUtama() {
        val intentBuka = Intent(this, com.example.MainActivity::class.java).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        startActivity(intentBuka)
    }

    override fun onDestroy() {
        pendaftarSiklusHidup.handleLifecycleEvent(Lifecycle.Event.ON_DESTROY)
        super.onDestroy()
    }
}
